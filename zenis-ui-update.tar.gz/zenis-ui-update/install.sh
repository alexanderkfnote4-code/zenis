#!/bin/bash
DW="$HOME/dune-weaver"; P="$(cd "$(dirname "$0")" && pwd)"
echo "-> Interfata noua (upload cu progres)"
rm -f "$DW/static/dist/assets/index-"*.js "$DW/static/dist/assets/index-"*.css
cp "$P"/static/dist/assets/* "$DW/static/dist/assets/"
for f in index.html sw.js registerSW.js; do cp "$P/static/dist/$f" "$DW/static/dist/"; done
F=$(sudo grep -rl "client_max_body_size" /etc/nginx 2>/dev/null)
[ -n "$F" ] && sudo sed -i -E 's/client_max_body_size [0-9]+[MmKk]?;/client_max_body_size 200M;/' $F && sudo nginx -t -q && sudo systemctl reload nginx
sudo systemctl restart dune-weaver
for i in $(seq 1 40); do sleep 1; curl -sf -m 2 http://localhost/api/audio/status >/dev/null && { echo ">>> GATA dupa ${i}s - apasa Ctrl+F5 in browser"; exit 0; }; done
echo "!!! ZeNis nu raspunde:"; sudo journalctl -u dune-weaver -n 15 --no-pager | tail -15
