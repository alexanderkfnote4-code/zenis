#!/bin/bash
# ZeNis overlay: aplica toate modificarile ZeNis peste Dune Weaver.
# Folosit de zenis-install.sh (instalare) si de zenis-update (actualizare).
# Utilizare: bash apply.sh [director_dune_weaver]
set -u
SRC="$(cd "$(dirname "$0")" && pwd)"
DW="${1:-$HOME/dune-weaver}"
[ -f "$DW/main.py" ] || { echo "!!! Nu gasesc $DW/main.py"; exit 1; }
OWNER=$(stat -c %U "$DW"); OUID=$(id -u "$OWNER"); OHOME=$(getent passwd "$OWNER" | cut -d: -f6)
VER=$(cat "$SRC/ZENIS_VERSION" 2>/dev/null || echo "?")
as_root(){ if [ "$(id -u)" = 0 ]; then "$@"; else sudo "$@"; fi; }
as_user(){ if [ "$(id -u)" = 0 ]; then runuser -u "$OWNER" -- env XDG_RUNTIME_DIR=/run/user/$OUID "$@"; else env XDG_RUNTIME_DIR=/run/user/$OUID "$@"; fi; }
say(){ echo -e "\033[38;5;179m-> $*\033[0m"; }

echo "=========== ZeNis $VER -> $DW (utilizator: $OWNER) ==========="

# serverul ruleaza ca root si creeaza fisiere proprii (__pycache__, state.json):
# le preluam ca sa le putem inlocui (la fel face installer-ul original)
as_root chown -R "$OWNER:" "$DW"

say "1/9 Backup"
BK="$OHOME/.zenis-backup/$(date +%Y%m%d-%H%M%S)"; mkdir -p "$BK"
cp -a "$DW/main.py" "$DW/modules/core/state.py" "$DW/modules/core/version_manager.py" "$DW/modules/core/pattern_manager.py" "$BK/" 2>/dev/null
[ -d "$DW/static/dist" ] && cp -a "$DW/static/dist" "$BK/dist"
[ -f "$DW/static/draw.html" ] && cp -a "$DW/static/draw.html" "$BK/"
[ -d "$DW/modules/audio" ] && mkdir -p "$BK/audio" && cp "$DW"/modules/audio/*.py "$BK/audio/" 2>/dev/null
[ -d "$DW/modules/routines" ] && mkdir -p "$BK/routines" && cp "$DW"/modules/routines/*.py "$BK/routines/" 2>/dev/null
[ -d "$DW/modules/live" ] && mkdir -p "$BK/live" && cp "$DW"/modules/live/*.py "$BK/live/" 2>/dev/null
[ -f "$DW/static/live.html" ] && cp -a "$DW/static/live.html" "$BK/"
ls -1dt "$OHOME"/.zenis-backup/*/ 2>/dev/null | tail -n +6 | xargs -r rm -rf   # pastreaza ultimele 5
restore(){
  echo "!!! Revin la versiunea anterioara din $BK"
  cp -a "$BK/main.py" "$DW/main.py"; cp -a "$BK/state.py" "$DW/modules/core/state.py"
  cp -a "$BK/version_manager.py" "$DW/modules/core/version_manager.py"
  [ -f "$BK/pattern_manager.py" ] && cp -a "$BK/pattern_manager.py" "$DW/modules/core/pattern_manager.py"
  [ -d "$BK/dist" ] && rm -rf "$DW/static/dist" && cp -a "$BK/dist" "$DW/static/dist"
  [ -f "$BK/draw.html" ] && cp -a "$BK/draw.html" "$DW/static/draw.html"
  rm -rf "$DW/modules/audio"; if [ -d "$BK/audio" ]; then mkdir -p "$DW/modules/audio"; cp "$BK"/audio/*.py "$DW/modules/audio/"; fi
  rm -rf "$DW/modules/routines"; if [ -d "$BK/routines" ]; then mkdir -p "$DW/modules/routines"; cp "$BK"/routines/*.py "$DW/modules/routines/"; fi
  rm -rf "$DW/modules/live"; if [ -d "$BK/live" ]; then mkdir -p "$DW/modules/live"; cp "$BK"/live/*.py "$DW/modules/live/"; fi
  [ -f "$BK/live.html" ] && cp -a "$BK/live.html" "$DW/static/live.html"
  as_root systemctl restart dune-weaver
}

say "2/9 Interfata ZeNis (tema, Deseneaza, Live, Audio, Rutine)"
rm -rf "$DW/static/dist"; cp -r "$SRC/files/static/dist" "$DW/static/dist"
cp "$SRC/files/static/draw.html" "$DW/static/draw.html"
cp "$SRC/files/static/live.html" "$DW/static/live.html"

say "3/9 Module audio + rutine + live (fisier cu fisier)"
for M in audio routines live; do
  rm -rf "$DW/modules/$M"; mkdir -p "$DW/modules/$M"; cp "$SRC"/files/modules/$M/*.py "$DW/modules/$M/"
done

say "4/9 Cod server: audio, update din repo ZeNis, nume ZeNis"
as_root cp "$SRC/zenis-update" /usr/local/bin/zenis-update; as_root chmod +x /usr/local/bin/zenis-update
ZENIS_SRC="$SRC" python3 - "$DW" << 'PY'
import sys, re, os
dw = sys.argv[1]
def patch(path, fn):
    s = open(path, encoding="utf-8").read(); n = fn(s)
    if n != s: open(path, "w", encoding="utf-8").write(n)
def main_py(s):
    L = s.splitlines()
    if not any(l.startswith("from modules.audio import audio_routes") for l in L):
        L.insert(max(i for i, l in enumerate(L) if l.startswith("from modules.")) + 1, "from modules.audio import audio_routes")
    if not any("include_router(audio_routes" in l for l in L):
        L.insert(max(i for i, l in enumerate(L) if l.startswith("app = FastAPI(")) + 1,
                 'app.include_router(audio_routes.router, prefix="/api/audio", tags=["audio"])')
    if not any(l.startswith("from modules.routines import routines") for l in L):
        L.insert(max(i for i, l in enumerate(L) if l.startswith("from modules.audio import audio_routes")) + 1,
                 "from modules.routines import routines as zenis_routines")
    if not any("include_router(zenis_routines" in l for l in L):
        L.insert(max(i for i, l in enumerate(L) if "include_router(audio_routes" in l) + 1,
                 'app.include_router(zenis_routines.router, prefix="/api/routines", tags=["routines"])')
    if not any(l.startswith("from modules.live import live") for l in L):
        L.insert(max(i for i, l in enumerate(L) if l.startswith("from modules.routines import routines")) + 1,
                 "from modules.live import live as zenis_live")
    if not any("include_router(zenis_live" in l for l in L):
        L.insert(max(i for i, l in enumerate(L) if "include_router(zenis_routines" in l) + 1,
                 'app.include_router(zenis_live.router, prefix="/api/live", tags=["live"])')
    L = [re.sub(r"^# (from modules\.audio import audio_routes|app\.include_router\(audio_routes)", r"\1", l) for l in L]
    s = "\n".join(L) + "\n"
    s = s.replace("dw_path = '/usr/local/bin/dw'", "dw_path = '/usr/local/bin/zenis-update'")
    s = s.replace("[dw_path, 'update'],", "['systemd-run', '--collect', '--unit', 'zenis-update', dw_path],")
    return s
patch(f"{dw}/main.py", main_py)
patch(f"{dw}/main.py", lambda s: s.replace('or "Dune Weaver"', 'or "ZeNis"').replace('app_name = "Dune Weaver"', 'app_name = "ZeNis"'))
OLD_CALL = """                await run_theta_rho_file(
                    file_path,
                    is_playlist=True,
                    clear_pattern=clear_pattern,"""
NEW_CALL = """                _zenis_skip = getattr(state, "zenis_skip_first_clear", False)
                state.zenis_skip_first_clear = False
                await run_theta_rho_file(
                    file_path,
                    is_playlist=True,
                    clear_pattern=None if _zenis_skip else clear_pattern,"""
def pm(s):
    if "_zenis_skip" in s: return s
    if OLD_CALL not in s: print("   ATENTIE: nu am gasit locul pentru 'fara curatare la primul model'"); return s
    return s.replace(OLD_CALL, NEW_CALL, 1)
patch(f"{dw}/modules/core/pattern_manager.py", pm)
OLD_SS = """def is_in_scheduled_pause_period():
    \"\"\"Check if current time falls within any scheduled pause period.\"\"\"
"""
NEW_SS = OLD_SS + """    if getattr(state, "zenis_ignore_pause", False):   # ZeNis: alarma Good Morning are prioritate
        return False
"""
def pm_ss(s):
    if "zenis_ignore_pause" in s: return s
    if OLD_SS not in s: print("   ATENTIE: nu am gasit verificarea Still Sands"); return s
    return s.replace(OLD_SS, NEW_SS, 1)
patch(f"{dw}/modules/core/pattern_manager.py", pm_ss)
patch(f"{dw}/modules/core/state.py", lambda s: re.sub(r'((?:app_name|table_name|mqtt_device_name)\b[^\n]*?)"Dune Weaver"', r'\1"ZeNis"', s))
patch(f"{dw}/modules/core/version_manager.py", lambda s: s.replace('self.repo_owner = "tuanchris"', 'self.repo_owner = "alexanderkfnote4-code"').replace('self.repo_name = "dune-weaver"', 'self.repo_name = "zenis"'))
_vm_extra = open(os.path.join(os.environ["ZENIS_SRC"], "files/patches/version_manager_zenis.py"), encoding="utf-8").read()
patch(f"{dw}/modules/core/version_manager.py", lambda s: s if "_zenis_current_version" in s else s.rstrip("\n") + "\n" + _vm_extra)
import os
w = f"{dw}/wifi/setup-wifi.sh"
if os.path.exists(w): patch(w, lambda s: s.replace('HOTSPOT_SSID="Dune Weaver"', 'HOTSPOT_SSID="ZeNis"'))
print("   cod actualizat")
PY

say "5/9 Test import server (inainte de restart)"
IMPERR=$(mktemp)
cd "$DW"
if ! as_root .venv/bin/python -c "import modules.audio.audio_routes, modules.routines.routines, modules.live.live, ast; ast.parse(open('main.py').read()); ast.parse(open('modules/core/pattern_manager.py').read()); import modules.core.version_manager" 2>"$IMPERR"; then
  echo "!!! Test esuat:"; tail -5 "$IMPERR"; restore; exit 1
fi

say "6/9 Sunet si Bluetooth (boxe BT pe Pi fara ecran)"
command -v pw-play >/dev/null && command -v mpg123 >/dev/null || as_root apt-get install -y -qq pipewire-bin mpg123 >/dev/null
as_root rfkill unblock bluetooth 2>/dev/null
MC=/etc/bluetooth/main.conf
if [ -f $MC ]; then
  grep -qE "^ControllerMode = bredr" $MC || { as_root sed -i -E '/^\s*#?\s*ControllerMode\s*=/d' $MC; as_root sed -i '/^\[General\]/a ControllerMode = bredr' $MC; BTR=1; }
  grep -qE "^TemporaryTimeout" $MC || { as_root sed -i '/^\[General\]/a TemporaryTimeout = 300' $MC; BTR=1; }
  [ "${BTR:-0}" = 1 ] && as_root systemctl restart bluetooth
fi
as_root loginctl enable-linger "$OWNER"
as_root mkdir -p "$OHOME/.config/wireplumber/wireplumber.conf.d" "$OHOME/zenis-audio"
as_root cp "$SRC/files/wireplumber/80-bluetooth-headless.conf" "$OHOME/.config/wireplumber/wireplumber.conf.d/"
as_root chown -R "$OWNER:" "$OHOME/.config/wireplumber" "$OHOME/zenis-audio"
sleep 1; as_user systemctl --user enable --now pipewire wireplumber >/dev/null 2>&1; as_user systemctl --user restart wireplumber >/dev/null 2>&1

say "7/9 Upload fisiere mari (200 MB)"
NG=$(as_root grep -rl "client_max_body_size" /etc/nginx 2>/dev/null)
[ -n "$NG" ] && as_root sed -i -E 's/client_max_body_size [0-9]+[MmKk]?;/client_max_body_size 200M;/' $NG && as_root nginx -t -q && as_root systemctl reload nginx

say "8/9 Nume ZeNis (setari existente + hotspot WiFi)"
as_root systemctl stop dune-weaver
as_root python3 - "$DW/state.json" << 'PY'
import json, sys, os
p = sys.argv[1]
if os.path.exists(p):
    d = json.load(open(p)); ch = False
    for k in ("app_name", "table_name", "mqtt_device_name"):
        if d.get(k) in (None, "", "Dune Weaver"): d[k] = "ZeNis"; ch = True
    if ch: json.dump(d, open(p, "w"), indent=2); print("   setari redenumite")
PY
nmcli -t -f NAME con show 2>/dev/null | while IFS= read -r C; do
  [ "$(nmcli -g 802-11-wireless.mode con show "$C" 2>/dev/null)" = "ap" ] || continue
  [ "$(nmcli -g 802-11-wireless.ssid con show "$C" 2>/dev/null)" = "Dune Weaver" ] && as_root nmcli con modify "$C" 802-11-wireless.ssid "ZeNis" && echo "   hotspot redenumit ZeNis"
done
echo "$VER" > "$DW/ZENIS_VERSION"

say "9/9 Pornesc ZeNis"
as_root systemctl start dune-weaver
for i in $(seq 1 60); do
  sleep 1
  if curl -sf -m 2 http://localhost/api/audio/status >/dev/null; then
    echo -e "\033[32m>>> ZeNis $VER PORNIT dupa ${i}s. Deschide http://$(hostname).local si apasa Ctrl+F5\033[0m"; exit 0
  fi
done
echo "!!! ZeNis nu raspunde dupa 60s:"; as_root journalctl -u dune-weaver -n 20 --no-pager | tail -20
restore; exit 1
