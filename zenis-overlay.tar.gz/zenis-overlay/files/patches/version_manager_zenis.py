
# ── ZeNis: versiuni ZeNis in loc de Dune Weaver (adaugat de zenis apply.sh) ──
_ZENIS_RAW = os.environ.get("ZENIS_REPO_RAW", "https://raw.githubusercontent.com/alexanderkfnote4-code/zenis/main")
_ZENIS_REPO = "https://github.com/alexanderkfnote4-code/zenis"

async def _zenis_current_version(self):
    """Versiunea ZeNis instalata (fisierul ZENIS_VERSION)."""
    try:
        p = Path(__file__).parent.parent.parent / "ZENIS_VERSION"
        if p.exists():
            return (await asyncio.to_thread(p.read_text)).strip()
    except Exception as e:
        logger.warning(f"ZeNis: nu pot citi versiunea instalata: {e}")
    return "1.0.0"

def _zenis_fetch_latest():
    import urllib.request
    url = f"{_ZENIS_RAW}/ZENIS_VERSION?t={int(time.time())}"      # ocoleste cache-ul GitHub
    with urllib.request.urlopen(url, timeout=8) as r:
        return r.read().decode().strip()

async def _zenis_latest_release(self, force_refresh: bool = False):
    """Ultima versiune ZeNis publicata (fisierul ZENIS_VERSION din repo)."""
    now = time.time()
    if (not force_refresh and self._latest_release_cache is not None
            and self._cache_timestamp is not None and now - self._cache_timestamp < 300):
        return self._latest_release_cache
    try:
        v = await asyncio.to_thread(_zenis_fetch_latest)
        if not v or not all(x.isdigit() for x in v.split(".")):
            raise ValueError(f"versiune invalida: {v!r}")
        data = {"version": v, "name": f"ZeNis {v}", "published_at": "", "html_url": _ZENIS_REPO,
                "body": "", "prerelease": False}
        self._latest_release_cache, self._cache_timestamp = data, now
        return data
    except Exception as e:
        logger.warning(f"ZeNis: nu pot citi ultima versiune din GitHub: {e}")
        return self._latest_release_cache

VersionManager.get_current_version = _zenis_current_version
VersionManager.get_latest_release = _zenis_latest_release
