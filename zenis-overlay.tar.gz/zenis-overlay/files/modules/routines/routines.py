"""ZeNis Rutine: Good Morning (trezire treptata) si Good Night (curatare + stingere treptata)."""
import datetime, json, logging, threading, time, urllib.request, uuid
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from modules.audio import audio_manager as audio

logger = logging.getLogger(__name__)
router = APIRouter()
API = "http://127.0.0.1:8080"
FILE = audio.AUDIO_DIR / "routines.json"
START_LEVEL = 10          # % de la care porneste GM si la care ajunge GN in centru
GM_INTRO_S = 10           # secunde doar muzica + lumina 10%, inainte sa porneasca bila
GM_RAMP_S = 300           # 5 minute de crestere
GN_HOLD_S = 5             # dupa ce bila ajunge in centru
GN_FADE_S = 10            # stingere finala 10% -> 0%

DEFAULTS = {
    "gm": {"time": "07:00", "days": [0, 1, 2, 3, 4, 5, 6], "playlist": "",
           "run_mode": "single", "song": "", "volume": 60, "light": 80},
    "gn": {"time": "22:30", "days": [0, 1, 2, 3, 4, 5, 6], "song": ""},
}
_cfg = json.loads(json.dumps(DEFAULTS))        # ultimele valori folosite in editor
_alarms = []                                   # alarme salvate (toate sunt active)
_last_run = {}
_active = {"name": None, "phase": "", "cancel": threading.Event(), "thread": None,
           "restore": {}, "music": False, "done": False}

def _clean(kind, d):
    """Pastreaza doar campurile cunoscute, cu valori valide."""
    out = dict(DEFAULTS[kind])
    out.update({k: v for k, v in (d or {}).items() if k in DEFAULTS[kind]})
    hh, mm = (str(out["time"]) + ":00").split(":")[:2]
    out["time"] = f"{max(0, min(23, int(hh))):02d}:{max(0, min(59, int(mm))):02d}"
    out["days"] = sorted({int(x) for x in out["days"] if 0 <= int(x) <= 6})
    for k in ("volume", "light"):
        if k in out:
            out[k] = max(10, min(100, int(out[k])))
    return out

# ── utilitare ────────────────────────────────────────────────────
def _load():
    try:
        d = json.loads(FILE.read_text())
    except Exception:
        return
    for k in ("gm", "gn"):
        if isinstance(d.get("draft", {}).get(k), dict):
            _cfg[k] = _clean(k, d["draft"][k])
    if isinstance(d.get("alarms"), list):
        for x in d["alarms"]:
            if x.get("type") in ("gm", "gn"):
                a = _clean(x["type"], x); a.update(id=x.get("id") or uuid.uuid4().hex[:8],
                                                  type=x["type"], created=x.get("created", ""),
                                                  enabled=bool(x.get("enabled", True)))
                _alarms.append(a)
    else:                                       # format vechi (v1.1-1.2): gm/gn cu comutator
        for k in ("gm", "gn"):
            old = d.get(k)
            if isinstance(old, dict):
                _cfg[k] = _clean(k, old)
                if old.get("enabled"):
                    a = _clean(k, old); a.update(id=uuid.uuid4().hex[:8], type=k, created="", enabled=True)
                    _alarms.append(a)
        _save()

def _save():
    try:
        FILE.write_text(json.dumps({"alarms": _alarms, "draft": _cfg}, indent=2))
    except Exception as e:
        logger.warning(f"routines save: {e}")

def _post(path, data=None, timeout=90):
    req = urllib.request.Request(API + path, data=json.dumps(data or {}).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status
    except Exception as e:
        logger.warning(f"routine POST {path}: {e}")
        return None

def _state():
    from modules.core.state import state
    return state

def _clock_info():
    """Ora vine de pe internet (NTP) si se afiseaza in fusul orar al Pi-ului."""
    tz = ""
    try:
        tz = open("/etc/timezone").read().strip()
    except Exception:
        try:
            import os
            tz = os.path.realpath("/etc/localtime").split("zoneinfo/")[-1]
        except Exception:
            pass
    synced = None
    try:
        import subprocess
        out = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
                             capture_output=True, text=True, timeout=3).stdout.strip()
        synced = out == "yes" if out else None
    except Exception:
        pass
    return tz, synced

def _phase(p):
    _active["phase"] = p
    logger.info(f"Rutina {_active['name']}: {p}")

def _sleep(sec):
    """Asteapta, dar se opreste imediat daca rutina e anulata."""
    return not _active["cancel"].wait(sec)

# ── lumini ───────────────────────────────────────────────────────
def _led():
    s = _state()
    return getattr(s, "led_controller", None), getattr(s, "led_provider", None)

def light_get():
    lc, prov = _led()
    if not lc:
        return None
    try:
        if prov == "wled":
            b = lc.check_status().get("brightness")
            return round(b / 2.55) if b is not None else 100
        return float(getattr(_state(), "dw_led_brightness", 35) or 35)
    except Exception:
        return None

def light_set(pct):
    lc, prov = _led()
    if not lc:
        return
    v = max(0, min(100, pct))
    try:
        c = lc.get_controller()
        c.set_brightness(int(round(v * 2.55)) if prov == "wled" else int(round(v)))
    except Exception as e:
        logger.debug(f"light_set: {e}")

def light_power(on):
    lc, _ = _led()
    if lc:
        try: lc.set_power(1 if on else 0)
        except Exception as e: logger.debug(f"light_power: {e}")

def _suppress_idle_led(on):
    """Dune Weaver pune efectul de repaus (ex. alb) cand se termina un model.
    In Good Night il blocam, ca luminile sa ramana pe scena aleasa pana se sting."""
    lc, _ = _led()
    if not lc:
        return
    if on:
        async def _noop_async(*a, **k): return True
        lc.effect_idle = lambda *a, **k: True
        lc.effect_idle_async = _noop_async
    else:
        lc.__dict__.pop("effect_idle", None)
        lc.__dict__.pop("effect_idle_async", None)

def _levels(vol, light):
    audio.set_volume(int(round(vol)))
    if light is not None:
        light_set(light)

# ── Good Morning ─────────────────────────────────────────────────
def _run_gm(c):
    tgt_v, tgt_l = int(c["volume"]), int(c["light"])
    has_led = _led()[0] is not None
    _phase("pornesc muzica si lumina la 10%")
    audio.set_volume(START_LEVEL)
    if has_led:
        light_power(True); light_set(START_LEVEL)
    if c.get("song"):
        audio.stop_playback()
        audio.play_file(c["song"])
        audio._sync_state["started_by_sync"] = True
    audio._session["follow"] = True        # dupa melodia de start continua cu restul
    audio._sync_state["inactive_since"] = None   # masa statea de mult: nu opri melodia de trezire
    audio._sync_state["suppress"] = False
    if not _sleep(GM_INTRO_S):
        return
    if c.get("playlist"):
        _phase(f"pornesc playlistul {c['playlist']}")
        _state().zenis_skip_first_clear = True          # nisipul e deja curatat de Good Night
        _post("/run_playlist", {"playlist_name": c["playlist"], "run_mode": c.get("run_mode", "single"),
                                "pause_time": 5, "clear_pattern": "adaptive", "shuffle": False})
    _phase("cresc treptat sunetul si lumina (5 minute)")
    t0 = time.time(); seen_run = False; idle_since = None
    while True:
        running = bool(_state().current_playing_file)
        seen_run = seen_run or running
        if seen_run and not running:
            idle_since = idle_since or time.time()
            if time.time() - idle_since > 15:
                _phase("masa a fost oprita - opresc cresterea"); break
        else:
            idle_since = None
        f = min(1.0, (time.time() - t0) / GM_RAMP_S)
        _levels(START_LEVEL + (tgt_v - START_LEVEL) * f,
                START_LEVEL + (tgt_l - START_LEVEL) * f if has_led else None)
        if f >= 1.0 or not _sleep(2):
            break
    if not _active["cancel"].is_set():
        _active["done"] = True
    _phase("gata")

# ── Good Night ───────────────────────────────────────────────────
def _takeover():
    """Utilizatorul a pornit altceva pe masa -> rutina se retrage."""
    _phase("ai pornit altceva pe masa - opresc rutina")
    _active["cancel"].set()

GN_FILE = "custom_patterns/zenis_good_night.thr"

def _gn_clear_file():
    """Curatarea 'din exterior spre centru' a mesei, rotita sa inceapa exact la unghiul bilei.
    Bila iese drept pe raza pana la margine, apoi curata in spirala spre centru."""
    import math, os
    from modules.core import pattern_manager as pm
    s = _state()
    src = pm.get_clear_pattern_file("clear_from_out")
    if src and not os.path.exists(src):
        src = os.path.join(pm.THETA_RHO_DIR, src)
    coords = pm.parse_theta_rho_file(src)
    if not coords or len(coords) < 2:
        raise RuntimeError(f"model de curatare invalid: {src}")
    tc = (getattr(s, "current_theta", 0) or 0) % (2 * math.pi)
    shift = tc - coords[0][0]
    out = os.path.join(pm.THETA_RHO_DIR, GN_FILE)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        f.write("# ZeNis Good Night: curatare rotita la pozitia bilei\n")
        f.writelines(f"{t + shift:.5f} {r:.5f}\n" for t, r in coords)
    logger.info(f"Good Night: curatare {os.path.basename(src)} rotita cu {shift:.3f} rad (bila la {tc:.3f} rad, rho {s.current_rho})")
    return GN_FILE

def _run_gn(c):
    s = _state()
    v0 = _active["restore"]["v"]
    l0 = _active["restore"]["l"]
    audio._session["follow"] = False
    _suppress_idle_led(True)
    _phase("opresc ce ruleaza")
    if s.current_playing_file:
        _post("/stop_execution")
        for _ in range(60):
            if not s.current_playing_file or not _sleep(1):
                break
    if c.get("song"):
        audio.stop_playback(); audio.play_file(c["song"])
    audio._sync_state["suppress"] = True     # sincronizarea nu porneste alte melodii peste Good Night

    _phase("bila iese pe raza spre margine, apoi curata spre centru")
    _post("/run_theta_rho", {"file_name": _gn_clear_file(), "pre_execution": "none"})
    started = False
    for _ in range(7200):                                  # max ~1h
        cur = s.current_playing_file
        running = bool(cur)
        if running and "zenis_good_night" not in str(cur):
            return _takeover()
        started = started or running
        prog = s.execution_progress
        if running and isinstance(prog, (list, tuple)) and len(prog) >= 2 and prog[1]:
            f = min(1.0, prog[0] / prog[1])
            _levels(v0 - (v0 - START_LEVEL) * f, None if l0 is None else l0 - (l0 - START_LEVEL) * f)
        if c.get("song") and running and not audio.get_status()["playing"]:
            audio.play_file(c["song"])                    # melodia se repeta pana ajunge bila
        if started and not running:
            break
        if not _sleep(0.5):
            return
    _levels(START_LEVEL, START_LEVEL if l0 is not None else None)
    _phase("bila e in centru")
    if not _sleep(GN_HOLD_S):
        return
    _phase("sting treptat")
    steps = GN_FADE_S * 2
    for i in range(1, steps + 1):
        f = i / steps
        _levels(START_LEVEL * (1 - f), None if l0 is None else START_LEVEL * (1 - f))
        if not _sleep(0.5):
            return
    audio.stop_playback()
    light_power(False)
    audio.set_volume(int(v0))                              # volumul revine pentru redari viitoare
    _active["done"] = True
    _phase("noapte buna")

# ── rulare / planificare ─────────────────────────────────────────
def _undo():
    """Rutina oprita (manual sau preluata): muzica ei se opreste, nivelurile revin."""
    r = _active.get("restore") or {}
    audio._session["follow"] = False
    audio._sync_state["suppress"] = False
    if _active.get("music"):
        audio.stop_playback()
    if r.get("v") is not None:
        audio.set_volume(int(r["v"]))
    if r.get("l") is not None:
        light_set(r["l"])

def start(name, cfg=None):
    stop()
    cancel = threading.Event()
    _active.update(name=name, phase="pornire", cancel=cancel, done=False,
                   music=bool((cfg or _cfg[name]).get("song")) or name == "gm",
                   restore={"v": audio.get_status()["volume"] or 50, "l": light_get()})
    fn = _run_gm if name == "gm" else _run_gn
    cfg = _clean(name, cfg if cfg is not None else _cfg[name])
    def runner():
        try:
            fn(cfg)
        except Exception as e:
            logger.exception(f"rutina {name}: {e}")
        finally:
            _suppress_idle_led(False)
            if cancel.is_set() and not _active.get("done"):
                _undo()
            if _active.get("cancel") is cancel:
                _active["name"] = None
    _active["thread"] = threading.Thread(target=runner, daemon=True)
    _active["thread"].start()

def stop():
    t = _active.get("thread")
    if _active["name"] and t:
        _active["cancel"].set()
        t.join(timeout=8)
    _active["name"] = None

def _due(now):
    """Alarmele care trebuie pornite acum (o singura data pe zi fiecare)."""
    out = []
    for a in list(_alarms):
        key = f"{a['id']}:{now:%Y-%m-%d %H:%M}"
        if a.get("enabled", True) and now.weekday() in a["days"] and now.strftime("%H:%M") == a["time"] and _last_run.get(a["id"]) != key:
            _last_run[a["id"]] = key
            out.append(a)
    return out

def _scheduler():
    time.sleep(20)                                         # lasam serverul sa porneasca
    while True:
        try:
            for a in _due(datetime.datetime.now()):
                logger.info(f"Alarma {a['type']} {a['time']} ({a['id']}) porneste")
                start(a["type"], a)
        except Exception as e:
            logger.warning(f"scheduler: {e}")
        time.sleep(10)

_load()
threading.Thread(target=_scheduler, daemon=True).start()

# ── API ──────────────────────────────────────────────────────────
class AlarmReq(BaseModel):
    type: str
    config: dict

class RunReq(BaseModel):
    name: str
    config: dict | None = None

@router.get("")
async def api_get():
    try:
        from modules.core import playlist_manager
        playlists = playlist_manager.list_all_playlists()
    except Exception:
        playlists = []
    now = datetime.datetime.now().astimezone()
    tz, synced = _clock_info()
    return {"gm": _cfg["gm"], "gn": _cfg["gn"], "alarms": sorted(_alarms, key=lambda a: a["time"]), "now": now.strftime("%H:%M"), "tz": tz or str(now.tzinfo),
            "synced": synced, "today": now.strftime("%d.%m.%Y"),
            "active": {"name": _active["name"], "phase": _active["phase"]} if _active["name"] else None,
            "playlists": playlists, "files": audio.list_audio_files(), "has_led": _led()[0] is not None}

@router.post("/alarms")
async def api_add_alarm(r: AlarmReq):
    if r.type not in ("gm", "gn"):
        raise HTTPException(400, "Tip necunoscut")
    a = _clean(r.type, r.config)
    if not a["days"]:
        raise HTTPException(400, "Alege cel putin o zi")
    _cfg[r.type] = dict(a)                                 # editorul tine minte ultimele valori
    a.update(id=uuid.uuid4().hex[:8], type=r.type, created=datetime.datetime.now().strftime("%d.%m.%Y %H:%M"), enabled=True)
    _alarms.append(a)
    _save()
    return {"success": True, "alarm": a, "alarms": _alarms}

class EnableReq(BaseModel):
    enabled: bool

@router.post("/alarms/{alarm_id}/enabled")
async def api_enable_alarm(alarm_id: str, r: EnableReq):
    for a in _alarms:
        if a["id"] == alarm_id:
            a["enabled"] = r.enabled
            _save()
            return {"success": True, "alarms": _alarms}
    raise HTTPException(404, "Alarma nu exista")

@router.delete("/alarms/{alarm_id}")
async def api_delete_alarm(alarm_id: str):
    before = len(_alarms)
    _alarms[:] = [a for a in _alarms if a["id"] != alarm_id]
    if len(_alarms) == before:
        raise HTTPException(404, "Alarma nu exista")
    _save()
    return {"success": True, "alarms": _alarms}

@router.post("/run")
async def api_run(r: RunReq):
    if r.name not in ("gm", "gn"):
        raise HTTPException(400, "Rutina necunoscuta")
    start(r.name, r.config)
    return {"success": True}

@router.post("/stop")
async def api_stop():
    import asyncio
    await asyncio.get_event_loop().run_in_executor(None, stop)
    return {"success": True}
