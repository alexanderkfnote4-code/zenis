"""ZeNis Rutine: Good Morning (trezire treptata) si Good Night (curatare + stingere treptata)."""
import datetime, json, logging, threading, time, urllib.request
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from modules.audio import audio_manager as audio

logger = logging.getLogger(__name__)
router = APIRouter()
API = "http://127.0.0.1:8080"
FILE = audio.AUDIO_DIR / "routines.json"
START_LEVEL = 10          # % de la care porneste GM si la care ajunge GN in centru
GM_INTRO_S = 10           # secunde doar muzica + lumina 10%, inainte sa porneasca bila
GM_RAMP_S = 300           # 5 minute de crestere
GN_HOLD_S = 5             # dupa ce bila ajunge in centru
GN_FADE_S = 10            # stingere finala 10% -> 0%

DEFAULTS = {
    "gm": {"enabled": False, "time": "07:00", "days": [0, 1, 2, 3, 4, 5, 6], "playlist": "",
           "run_mode": "single", "song": "", "volume": 60, "light": 80},
    "gn": {"enabled": False, "time": "22:30", "days": [0, 1, 2, 3, 4, 5, 6], "song": ""},
}
_cfg = json.loads(json.dumps(DEFAULTS))
_last_run = {}
_active = {"name": None, "phase": "", "cancel": threading.Event(), "thread": None}

# ── utilitare ────────────────────────────────────────────────────
def _load():
    try:
        d = json.loads(FILE.read_text())
        for k in ("gm", "gn"):
            _cfg[k].update({kk: v for kk, v in d.get(k, {}).items() if kk in DEFAULTS[k]})
    except Exception:
        pass

def _save():
    try:
        FILE.write_text(json.dumps(_cfg, indent=2))
    except Exception as e:
        logger.warning(f"routines save: {e}")

def _post(path, data=None, timeout=90):
    req = urllib.request.Request(API + path, data=json.dumps(data or {}).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status
    except Exception as e:
        logger.warning(f"routine POST {path}: {e}")
        return None

def _state():
    from modules.core.state import state
    return state

def _phase(p):
    _active["phase"] = p
    logger.info(f"Rutina {_active['name']}: {p}")

def _sleep(sec):
    """Asteapta, dar se opreste imediat daca rutina e anulata."""
    return not _active["cancel"].wait(sec)

# ── lumini ───────────────────────────────────────────────────────
def _led():
    s = _state()
    return getattr(s, "led_controller", None), getattr(s, "led_provider", None)

def light_get():
    lc, prov = _led()
    if not lc:
        return None
    try:
        if prov == "wled":
            b = lc.check_status().get("brightness")
            return round(b / 2.55) if b is not None else 100
        return float(getattr(_state(), "dw_led_brightness", 35) or 35)
    except Exception:
        return None

def light_set(pct):
    lc, prov = _led()
    if not lc:
        return
    v = max(0, min(100, pct))
    try:
        c = lc.get_controller()
        c.set_brightness(int(round(v * 2.55)) if prov == "wled" else int(round(v)))
    except Exception as e:
        logger.debug(f"light_set: {e}")

def light_power(on):
    lc, _ = _led()
    if lc:
        try: lc.set_power(1 if on else 0)
        except Exception as e: logger.debug(f"light_power: {e}")

def _levels(vol, light):
    audio.set_volume(int(round(vol)))
    if light is not None:
        light_set(light)

# ── Good Morning ─────────────────────────────────────────────────
def _run_gm(c):
    tgt_v, tgt_l = int(c["volume"]), int(c["light"])
    has_led = _led()[0] is not None
    _phase("pornesc muzica si lumina la 10%")
    audio.set_volume(START_LEVEL)
    if has_led:
        light_power(True); light_set(START_LEVEL)
    if c.get("song"):
        audio.stop_playback()
        audio.play_file(c["song"])
        audio._sync_state["started_by_sync"] = True
    audio._session["follow"] = True        # dupa melodia de start continua cu restul
    audio._sync_state["inactive_since"] = None   # masa statea de mult: nu opri melodia de trezire
    audio._sync_state["suppress"] = False
    if not _sleep(GM_INTRO_S):
        return
    if c.get("playlist"):
        _phase(f"pornesc playlistul {c['playlist']}")
        _post("/run_playlist", {"playlist_name": c["playlist"], "run_mode": c.get("run_mode", "single"),
                                "pause_time": 5, "clear_pattern": "adaptive", "shuffle": False})
    _phase("cresc treptat sunetul si lumina (5 minute)")
    t0 = time.time()
    while True:
        f = min(1.0, (time.time() - t0) / GM_RAMP_S)
        _levels(START_LEVEL + (tgt_v - START_LEVEL) * f,
                START_LEVEL + (tgt_l - START_LEVEL) * f if has_led else None)
        if f >= 1.0 or not _sleep(2):
            break
    _phase("gata")

# ── Good Night ───────────────────────────────────────────────────
def _run_gn(c):
    s = _state()
    v0 = audio.get_status()["volume"] or 50
    l0 = light_get()
    audio._session["follow"] = False
    _phase("opresc ce ruleaza")
    if s.current_playing_file:
        _post("/stop_execution")
        for _ in range(60):
            if not s.current_playing_file or not _sleep(1):
                break
    if c.get("song"):
        audio.stop_playback(); audio.play_file(c["song"])
    audio._sync_state["suppress"] = True     # sincronizarea nu porneste alte melodii peste Good Night
    _phase("duc bila pe margine")
    _post("/move_to_perimeter", timeout=120)
    if _active["cancel"].is_set():
        return
    _phase("curatare spre centru")
    _post("/run_theta_rho", {"file_name": "clear_from_out.thr", "pre_execution": "none"})
    started = False
    for _ in range(3600):                                  # max ~1h
        prog = s.execution_progress
        running = bool(s.current_playing_file)
        started = started or running
        if isinstance(prog, (list, tuple)) and len(prog) >= 2 and prog[1]:
            f = min(1.0, prog[0] / prog[1])
            _levels(v0 - (v0 - START_LEVEL) * f, None if l0 is None else l0 - (l0 - START_LEVEL) * f)
        if c.get("song") and running and not audio.get_status()["playing"]:
            audio.play_file(c["song"])                    # melodia se repeta pana ajunge bila
        if started and not running:
            break
        if not _sleep(1):
            return
    _levels(START_LEVEL, START_LEVEL if l0 is not None else None)
    _phase("bila e in centru")
    if not _sleep(GN_HOLD_S):
        return
    _phase("sting treptat")
    steps = GN_FADE_S * 2
    for i in range(1, steps + 1):
        f = i / steps
        _levels(START_LEVEL * (1 - f), None if l0 is None else START_LEVEL * (1 - f))
        if not _sleep(0.5):
            return
    audio.stop_playback()
    light_power(False)
    audio.set_volume(int(v0))                              # volumul revine pentru redari viitoare
    _phase("noapte buna")

# ── rulare / planificare ─────────────────────────────────────────
def start(name):
    stop()
    _active.update(name=name, phase="pornire", cancel=threading.Event())
    fn = _run_gm if name == "gm" else _run_gn
    cfg = dict(_cfg[name])
    def runner():
        try:
            fn(cfg)
        except Exception as e:
            logger.exception(f"rutina {name}: {e}"); _phase(f"eroare: {e}")
        finally:
            _active["name"] = None
    _active["thread"] = threading.Thread(target=runner, daemon=True)
    _active["thread"].start()

def stop():
    if _active["name"]:
        _active["cancel"].set()
        t = _active.get("thread")
        if t: t.join(timeout=5)
    _active["name"] = None

def _scheduler():
    time.sleep(20)                                         # lasam serverul sa porneasca
    while True:
        try:
            now = datetime.datetime.now()
            for name in ("gm", "gn"):
                c = _cfg[name]
                key = f"{name}:{now:%Y-%m-%d}"
                if c["enabled"] and now.weekday() in c["days"] and now.strftime("%H:%M") == c["time"] \
                        and _last_run.get(name) != key:
                    _last_run[name] = key
                    logger.info(f"Pornesc rutina programata {name}")
                    start(name)
        except Exception as e:
            logger.warning(f"scheduler: {e}")
        time.sleep(15)

_load()
threading.Thread(target=_scheduler, daemon=True).start()

# ── API ──────────────────────────────────────────────────────────
class RoutinesUpdate(BaseModel):
    gm: dict | None = None
    gn: dict | None = None

class RunReq(BaseModel):
    name: str

@router.get("")
async def api_get():
    try:
        from modules.core import playlist_manager
        playlists = playlist_manager.list_all_playlists()
    except Exception:
        playlists = []
    now = datetime.datetime.now().astimezone()
    return {"gm": _cfg["gm"], "gn": _cfg["gn"], "now": now.strftime("%H:%M"), "tz": str(now.tzinfo),
            "active": {"name": _active["name"], "phase": _active["phase"]} if _active["name"] else None,
            "playlists": playlists, "files": audio.list_audio_files(), "has_led": _led()[0] is not None}

@router.post("")
async def api_set(u: RoutinesUpdate):
    for name in ("gm", "gn"):
        d = getattr(u, name)
        if d:
            _cfg[name].update({k: v for k, v in d.items() if k in DEFAULTS[name]})
    _save()
    return {"success": True, "gm": _cfg["gm"], "gn": _cfg["gn"]}

@router.post("/run")
async def api_run(r: RunReq):
    if r.name not in ("gm", "gn"):
        raise HTTPException(400, "Rutina necunoscuta")
    start(r.name)
    return {"success": True}

@router.post("/stop")
async def api_stop():
    import asyncio
    await asyncio.get_event_loop().run_in_executor(None, stop)
    return {"success": True}
