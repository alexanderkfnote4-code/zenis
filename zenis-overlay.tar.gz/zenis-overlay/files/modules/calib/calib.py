"""ZeNis: homing cu senzor magnetic pe unghi + pagina de calibrare.

Homing cu senzor (cand e bifat in Settings -> Homing):
  1. crash homing pe raza (bila la centru), ca pana acum
  2. bratul se roteste repede pana senzorul vede magnetul, apoi se da inapoi
  3. trece incet peste magnet si masoara unde incepe si unde se termina zona lui
  4. se opreste la mijlocul zonei, crash homing din nou pe raza
  5. unghiul curent devine offset-ul din Settings (implicit 0 = magnetul)
  In timpul rotirii, raza e compensata (aceeasi formula ca la desen), deci bila sta in centru.

Senzorul: modul Hall 3144E pe GPIO17 (pin fizic 11), alimentat la 3.3V. LOW = magnet in dreptul lui.

Calibrare: LED-ul 1 se leaga de unghiul magnetului (led1_from_magnet_deg), deci ramane corect
dupa fiecare homing. Pagina poate aprinde un singur LED, cadranele sau LED-ul din dreptul bilei.
"""
import asyncio, json, logging, math, os, subprocess, sys, threading, time
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter()

CFG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "zenis_calib.json")
DEFAULTS = {
    "sensor_enabled": False,   # Home foloseste senzorul magnetic
    "page_enabled": False,     # tab-ul Calibrare e vizibil
    "gpio": 17,
    "active_low": True,        # LOW = magnet detectat
    "zones": 5,                # cadrane; ultimul primeste LED-urile ramase (132 -> 26,26,26,26,28)
    "led1_from_magnet_deg": None,
    "led_reverse": False,
}
ZONE_COLORS = [(255, 0, 0), (255, 255, 255), (255, 150, 30), (120, 80, 255), (0, 200, 60), (0, 160, 255), (255, 0, 160), (255, 220, 0)]
FAST = 250        # mm/min pe axa unghiului: o tura (50 mm) in ~12 s
SLOW = 25         # trecerea lenta peste magnet: ~3 grade/s
HOME_TIMEOUT = 240
FX_ID = 240       # efect LED temporar folosit doar de calibrare

_lock = threading.RLock()
_last_home = {"ok": None, "time": None, "message": None, "zone_deg": None}
_homed_with_sensor = False
_led = {"mode": "off", "n": 1}


# ───────────────────────── configurare ─────────────────────────
def cfg() -> dict:
    with _lock:
        d = dict(DEFAULTS)
        try:
            with open(CFG_FILE, encoding="utf-8") as f:
                d.update({k: v for k, v in json.load(f).items() if k in DEFAULTS})
        except FileNotFoundError:
            pass
        except Exception as e:
            logger.warning(f"Calibrare: nu pot citi {CFG_FILE}: {e}")
        return d

def save_cfg(upd: dict) -> dict:
    with _lock:
        d = cfg()
        d.update({k: v for k, v in upd.items() if k in DEFAULTS})
        tmp = CFG_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.replace(tmp, CFG_FILE)
        return d

def _st():
    from modules.core.state import state
    return state

def _cm():
    from modules.connection import connection_manager
    return connection_manager


# ───────────────────────── senzor (GPIO) ─────────────────────────
class _Gpio:
    def __init__(self):
        self.pin = None
        self.mode = None      # "lgpio" sau "pinctrl"
        self.h = None
        self.error = None

    def _open(self, pin):
        self.close()
        self.pin, self.error = pin, None
        try:
            import lgpio
            model = ""
            try:
                model = open("/proc/device-tree/model").read()
            except Exception:
                pass
            for chip in ((4, 0) if "Pi 5" in model else (0, 4)):
                try:
                    h = lgpio.gpiochip_open(chip)
                except Exception:
                    continue
                try:
                    lgpio.gpio_claim_input(h, pin, lgpio.SET_PULL_UP)
                    self.lg, self.h, self.mode = lgpio, h, "lgpio"
                    return
                except Exception as e:
                    self.error = str(e)
                    lgpio.gpiochip_close(h)
        except ImportError:
            pass
        try:
            subprocess.run(["pinctrl", "set", str(pin), "ip", "pu"], capture_output=True, timeout=2)
            self.mode = "pinctrl"
        except Exception as e:
            self.mode, self.error = None, f"nici lgpio, nici pinctrl: {e}"

    def close(self):
        if self.mode == "lgpio" and self.h is not None:
            try:
                self.lg.gpiochip_close(self.h)
            except Exception:
                pass
        self.h, self.mode = None, None

    def level(self, pin) -> Optional[int]:
        if pin != self.pin or self.mode is None:
            self._open(pin)
        try:
            if self.mode == "lgpio":
                return self.lg.gpio_read(self.h, pin)
            if self.mode == "pinctrl":
                out = subprocess.run(["pinctrl", "get", str(pin)], capture_output=True, text=True, timeout=2).stdout
                return 1 if "| hi" in out else 0 if "| lo" in out else None
        except Exception as e:
            self.error = str(e)
            self.mode = None
        return None

_gpio = _Gpio()

def sensor_active() -> Optional[bool]:
    c = cfg()
    lv = _gpio.level(int(c["gpio"]))
    if lv is None:
        return None
    return (lv == 0) if c["active_low"] else (lv == 1)


# ───────────────────────── GRBL ─────────────────────────
class HomingError(Exception):
    pass

def _raw(b: bytes):
    """Caracter de timp real (ex. 0x85 = anulare jog). send() ar codifica 0x85 ca UTF-8 pe 2 octeti."""
    c = _st().conn
    ser = getattr(c, "ser", None)
    if ser is not None:
        with c.lock:
            ser.write(b)
            ser.flush()
    else:
        c.send(b.decode("latin-1"))

def _status(timeout=3.0) -> Optional[str]:
    c = _st().conn
    c.send("?")
    end = time.time() + timeout
    while time.time() < end:
        line = c.readline()
        if line and line.startswith("<"):
            return line
    return None

def _pos_x(st: Optional[str] = None) -> float:
    st = st or _status()
    pos = _cm().parse_machine_position(st) if st else None
    if not pos:
        raise HomingError("nu pot citi poziția de la GRBL")
    return pos[0]

def _wait_idle(timeout=60.0):
    end = time.time() + timeout
    while time.time() < end:
        st = _status()
        if st:
            if st.startswith("<Idle"):
                return st
            if st.startswith("<Alarm"):
                raise HomingError(f"GRBL în alarmă: {st}")
        time.sleep(0.1)
    raise HomingError("mișcarea nu s-a terminat la timp")

def _cmd(gcode: str, timeout=5.0):
    c = _st().conn
    c.send(gcode + "\n")
    end = time.time() + timeout
    while time.time() < end:
        line = c.readline()
        if not line:
            continue
        if line.lower() == "ok":
            return
        if line.lower().startswith("error"):
            raise HomingError(f"GRBL a refuzat „{gcode}”: {line}")
    raise HomingError(f"GRBL nu a răspuns la „{gcode}”")

def _drain():
    c = _st().conn
    try:
        while c.in_waiting() > 0:
            c.readline()
    except Exception:
        pass

MM_PER_DEG = 100 / (2 * 2 * 180)   # ca in pattern_manager: 2*pi rad = 100/2 mm pe X (x_scaling_factor = 2)

def _comp(dx: float) -> float:
    """Miscarea pe Y care tine raza pe loc cand X se roteste (copiat din formula de desen)."""
    s = _st()
    if not s.x_steps_per_mm or not s.y_steps_per_mm or not s.gear_ratio:
        return 0.0
    mini = s.table_type == "dune_weaver_mini"
    xsf, ysf = (2, 3.7) if mini else (2, 5)
    xt = s.x_steps_per_mm * (100 / xsf)
    yt = s.y_steps_per_mm * (100 / ysf)
    off = dx * (xt * xsf / (s.gear_ratio * yt * ysf))
    return -off if (mini or s.y_steps_per_mm == 546) else off

def _jog_mm(dx: float, feed: float):
    _cmd(f"$J=G91 G21 X{dx:.3f} Y{_comp(dx):.3f} F{feed:.0f}")

def _rotate(deg: float, feed=FAST):
    _jog_mm(deg * MM_PER_DEG, feed)
    _wait_idle(abs(deg * MM_PER_DEG) / feed * 60 + 15)

def _seek(deg: float, feed: float, want: bool) -> Optional[float]:
    """Roteste pana senzorul devine `want`; opreste bratul. Intoarce X la declansare sau None."""
    dx = deg * MM_PER_DEG
    _jog_mm(dx, feed)
    end = time.time() + abs(dx) / feed * 60 + 10
    hit, last_q = None, 0.0
    while time.time() < end:
        if sensor_active() == want:
            hit = _pos_x()
            break
        if time.time() - last_q > 0.25:
            last_q = time.time()
            st = _status()
            if st and st.startswith("<Idle"):
                if sensor_active() == want:
                    hit = _pos_x(st)
                break
        time.sleep(0.002)
    if hit is not None:
        _raw(b"\x85")
    _wait_idle()
    return hit

def _seek_zone(deg: float, feed: float):
    """Trecere lenta: intoarce (X unde incepe zona magnetului, X unde se termina) sau None."""
    dx = deg * MM_PER_DEG
    _jog_mm(dx, feed)
    end = time.time() + abs(dx) / feed * 60 + 10
    a = b = None
    last_q = 0.0
    while time.time() < end:
        act = sensor_active()
        if a is None and act:
            a = _pos_x()
        elif a is not None and act is False:
            b = _pos_x()
            break
        if time.time() - last_q > 0.25:
            last_q = time.time()
            st = _status()
            if st and st.startswith("<Idle"):
                break
        time.sleep(0.002)
    _raw(b"\x85")
    _wait_idle()
    return a, b

def _crash():
    s, cm = _st(), _cm()
    mini = (s.table_type_override or s.table_type) == "dune_weaver_mini"
    loop = asyncio.new_event_loop()
    try:
        ok = loop.run_until_complete(cm.send_grbl_coordinates(0, -30 if mini else -22, 100 if mini else 400, home=True))
    finally:
        loop.close()
    if not ok:
        raise HomingError("crash homing pe rază a eșuat")
    _wait_idle(60)

def _home_sensor():
    global _homed_with_sensor
    s, cm = _st(), _cm()
    if sensor_active() is None:
        raise HomingError(f"nu pot citi senzorul pe GPIO{cfg()['gpio']} ({_gpio.error or 'necunoscut'})")
    if not cm.check_and_unlock_alarm():
        raise HomingError("GRBL e în alarmă și nu se deblochează")
    _drain()
    logger.info("Home senzor: 1/5 rază la centru (crash)")
    _crash()
    if sensor_active():
        logger.info("Home senzor: magnetul e deja în dreptul senzorului, ies din zonă")
        if _seek(90, FAST, False) is None:
            raise HomingError("senzorul e activ tot timpul (verifică magnetul și potențiometrul)")
        _rotate(10)
    logger.info("Home senzor: 2/5 caut magnetul")
    if _seek(400, FAST, True) is None:
        raise HomingError("magnetul nu a fost găsit într-o tură completă")
    logger.info("Home senzor: 3/5 mă dau înapoi")
    if _seek(-60, FAST, False) is None:
        raise HomingError("zona magnetului e mai lată de 60° (magnetul e prea aproape sau prea puternic)")
    _rotate(-8)
    logger.info("Home senzor: 4/5 trecere lentă peste magnet")
    a, b = _seek_zone(90, SLOW)
    if a is None:
        raise HomingError("magnetul nu a mai fost găsit la trecerea lentă")
    center = (a + b) / 2 if b is not None else a
    zone = abs(b - a) / MM_PER_DEG if b is not None else None
    _jog_mm(center - _pos_x(), FAST)
    _wait_idle()
    logger.info("Home senzor: 5/5 rază la centru (crash)")
    _crash()
    pos = cm.get_machine_position()
    if not pos or pos[0] is None:
        raise HomingError("nu pot citi poziția finală")
    s.machine_x, s.machine_y = pos
    s.current_theta = math.radians(s.angular_homing_offset_degrees or 0.0)
    s.current_rho = 0
    s.save()
    _homed_with_sensor = True
    msg = f"magnet găsit, zonă {zone:.1f}°" if zone is not None else "magnet găsit (capătul zonei nu a fost măsurat)"
    logger.info(f"Home senzor: gata - {msg}, theta={s.angular_homing_offset_degrees}°")
    return zone, msg

def home_with_sensor(timeout=HOME_TIMEOUT) -> bool:
    done = threading.Event()
    res = {"ok": False, "msg": "timp depășit", "zone": None}

    def run():
        try:
            res["zone"], res["msg"] = _home_sensor()
            res["ok"] = True
        except Exception as e:
            res["msg"] = str(e)
            logger.error(f"Home senzor eșuat: {e}")
        finally:
            done.set()

    threading.Thread(target=run, daemon=True).start()
    if not done.wait(timeout):
        try:
            _raw(b"\x85")
            _st().conn.send("!\n")
        except Exception:
            pass
    if res["ok"]:
        _last_home.update({"ok": True, "time": time.time(), "message": res["msg"], "zone_deg": res["zone"]})
        return True
    # masa ramane utilizabila: homing fara senzor (raza la centru), dar unghiul nu e cunoscut
    global _homed_with_sensor
    _homed_with_sensor = False
    fallback = False
    if done.is_set():
        try:
            _wait_idle(30)
            _crash()
            s = _st()
            pos = _cm().get_machine_position()
            if pos and pos[0] is not None:
                s.machine_x, s.machine_y = pos
            s.current_theta, s.current_rho = 0, 0
            s.save()
            fallback = True
        except Exception as e:
            logger.error(f"Home senzor: nici homing-ul fără senzor nu a mers: {e}")
    msg = f"Senzor: {res['msg']}." + (" Am făcut homing fără senzor, unghiul nu e cunoscut." if fallback else "")
    _last_home.update({"ok": False, "time": time.time(), "message": msg, "zone_deg": None})
    return fallback

def _install():
    """Butonul Home (si homing-ul la pornire / din playlist) foloseste senzorul cand e bifat."""
    cm = _cm()
    if getattr(cm.home, "_zenis", False):
        return
    original = cm.home

    def home(timeout=120):
        if cfg()["sensor_enabled"]:
            return home_with_sensor()
        return original(timeout)

    home._zenis = True
    cm.home = home
    mu = sys.modules.get("modules.mqtt.utils")
    if mu is not None and hasattr(mu, "home"):
        mu.home = home

_install()


# ───────────────────────── LED-uri ─────────────────────────
def _led_count() -> int:
    try:
        from modules.ledover import ledover
        lc = ledover._led()
        return int(lc.get_controller().num_leds) if lc else 0
    except Exception:
        return 0

def zone_bounds(n: int, zones: int):
    base = n // zones
    return [(i * base, n if i == zones - 1 else (i + 1) * base) for i in range(zones)]

def _offset_deg() -> float:
    return float(_st().angular_homing_offset_degrees or 0.0)

def led_theta_deg(k: int, n: int, c: dict) -> Optional[float]:
    """Unghiul (grade) in dreptul LED-ului k (1..n), in sistemul mesei dupa homing."""
    if c["led1_from_magnet_deg"] is None or n <= 0:
        return None
    d = -1 if c["led_reverse"] else 1
    return _offset_deg() + c["led1_from_magnet_deg"] + d * (k - 1) * 360.0 / n

def led_at_theta(theta_deg: float, n: int, c: dict) -> Optional[int]:
    if c["led1_from_magnet_deg"] is None or n <= 0:
        return None
    d = -1 if c["led_reverse"] else 1
    rel = ((theta_deg - _offset_deg() - c["led1_from_magnet_deg"]) * d) % 360.0
    return int(round(rel / (360.0 / n))) % n + 1

def _fx(seg) -> int:
    n = seg.length
    buf = [0] * n
    m = _led["mode"]
    if m == "single":
        buf[(_led["n"] - 1) % n] = 0xFFFFFF
    elif m == "zones":
        for z, (a, b) in enumerate(zone_bounds(n, max(1, int(cfg()["zones"])))):
            r, g, bl = ZONE_COLORS[z % len(ZONE_COLORS)]
            for i in range(a, b):
                buf[i] = (r << 16) | (g << 8) | bl
    elif m == "follow":
        k = led_at_theta(math.degrees(_st().current_theta), n, cfg())
        if k:
            buf[k - 1] = 0xFFFFFF
            buf[k % n] = buf[(k - 2) % n] = 0x302010
    for i, c in enumerate(buf):
        seg.set_pixel_color(i, c)
    return 50

def set_leds(mode: str, n: int = 1):
    from modules.ledover import ledover
    import modules.led.dw_leds.effects.basic_effects as be
    if mode == "off":
        _led["mode"] = "off"
        if ledover._ov.get("active"):
            ledover.deactivate("calibrare")
        be.EFFECTS.pop(FX_ID, None)
        return
    lc = ledover._led()
    if not lc:
        raise HTTPException(400, "LED-urile DW nu sunt configurate (Settings → LED)")
    _led.update({"mode": mode, "n": max(1, int(n))})
    be.EFFECTS[FX_ID] = ("ZeNis Calibrare", _fx)
    ledover.activate()
    lc.set_power(1)
    lc.get_controller().set_effect(FX_ID)


# ───────────────────────── API ─────────────────────────
def _connected() -> bool:
    s = _st()
    return bool(s.conn and s.conn.is_connected())

class CfgReq(BaseModel):
    sensor_enabled: Optional[bool] = None
    page_enabled: Optional[bool] = None
    led_reverse: Optional[bool] = None
    zones: Optional[int] = None

@router.get("/config")
async def api_cfg():
    return cfg()

@router.post("/config")
async def api_set_cfg(r: CfgReq):
    upd = {k: v for k, v in r.dict().items() if v is not None}
    if "zones" in upd and not 1 <= upd["zones"] <= 8:
        raise HTTPException(400, "Numărul de cadrane trebuie să fie între 1 și 8")
    return save_cfg(upd)

@router.get("/status")
async def api_status():
    s, c = _st(), cfg()
    n = _led_count()
    th = math.degrees(s.current_theta or 0.0)
    from modules.ledover import ledover
    led_mode = _led["mode"] if ledover._ov.get("active") else "off"
    act = await asyncio.to_thread(sensor_active)
    return {
        "connected": _connected(),
        "homing": bool(s.is_homing),
        "busy": bool(s.current_playing_file),
        "theta_deg": th,
        "rho": s.current_rho or 0.0,
        "offset_deg": _offset_deg(),
        "sensor": {"active": act, "mode": _gpio.mode, "error": _gpio.error, "gpio": c["gpio"]},
        "sensor_enabled": c["sensor_enabled"],
        "homed_with_sensor": _homed_with_sensor,
        "last_home": _last_home,
        "led_count": n,
        "zones": [list(z) for z in zone_bounds(n, max(1, int(c["zones"])))] if n else [],
        "led1_from_magnet_deg": c["led1_from_magnet_deg"],
        "led_reverse": c["led_reverse"],
        "led1_theta_deg": led_theta_deg(1, n, c),
        "led_at_ball": led_at_theta(th, n, c),
        "led_mode": led_mode,
        "led_n": _led["n"],
    }

def _check_can_move():
    s = _st()
    if not _connected():
        raise HTTPException(400, "Masa nu e conectată")
    if s.is_homing:
        raise HTTPException(409, "Homing în curs")
    if s.current_playing_file:
        raise HTTPException(409, "Masa desenează; oprește întâi modelul")

async def _move(theta_rad: float, rho: float):
    from modules.core import pattern_manager
    s = _st()
    s.stop_requested = False
    await pattern_manager.move_polar(theta_rad, max(0.0, min(1.0, rho)))
    await _cm().check_idle_async(timeout=90)

class MoveReq(BaseModel):
    dtheta_deg: float = 0.0
    rho: Optional[float] = None
    drho: float = 0.0

@router.post("/move")
async def api_move(r: MoveReq):
    _check_can_move()
    s = _st()
    rho = r.rho if r.rho is not None else (s.current_rho or 0.0) + r.drho
    await _move((s.current_theta or 0.0) + math.radians(r.dtheta_deg), rho)
    return await api_status()

class LedGoReq(BaseModel):
    n: int
    rho: float = 1.0

@router.post("/goto-led")
async def api_goto_led(r: LedGoReq):
    _check_can_move()
    s, c, n = _st(), cfg(), _led_count()
    target = led_theta_deg(r.n, n, c)
    if target is None:
        raise HTTPException(400, "Calibrează întâi LED-ul 1")
    cur = math.degrees(s.current_theta or 0.0)
    delta = (target - cur + 180.0) % 360.0 - 180.0      # pe drumul cel mai scurt
    await asyncio.to_thread(set_leds, "single", r.n)
    await _move(math.radians(cur + delta), r.rho)
    return await api_status()

@router.post("/set-led1")
async def api_set_led1():
    s = _st()
    if not _homed_with_sensor:
        raise HTTPException(400, "Fă întâi Home cu senzorul, ca unghiul să fie cunoscut")
    if (s.current_rho or 0) < 0.5:
        raise HTTPException(400, "Mută bila la margine, în dreptul LED-ului 1")
    rel = (math.degrees(s.current_theta) - _offset_deg()) % 360.0
    save_cfg({"led1_from_magnet_deg": round(rel, 2)})
    logger.info(f"Calibrare: LED 1 la {rel:.2f}° față de magnet")
    return await api_status()

class LedReq(BaseModel):
    mode: str
    n: int = 1

@router.post("/leds")
async def api_leds(r: LedReq):
    if r.mode not in ("off", "single", "zones", "follow"):
        raise HTTPException(400, "mod LED necunoscut")
    await asyncio.to_thread(set_leds, r.mode, r.n)
    return await api_status()
