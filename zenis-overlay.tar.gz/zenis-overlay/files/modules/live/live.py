"""ZeNis Live: desenezi cu degetul, masa deseneaza dupa o pauza scurta.
Cat e activ modul: LED-urile pe efectul de 'rulare' si muzica porneste, ca la un model."""
import asyncio, logging, math, threading, time
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from modules.audio import audio_manager as audio

logger = logging.getLogger(__name__)
router = APIRouter()
TAU = 2 * math.pi
STEP = 0.01          # pas maxim intre puncte (1% din raza): liniile raman drepte pe masa
CENTER = 0.02        # sub 2% din raza = "in centru" (rotirea se face la rho exact 0)
IDLE_OFF_S = 600     # modul se opreste singur dupa 10 minute fara desen

_live = {"active": False, "speed": None, "queue": [], "task": None, "last": 0.0,
         "music_thread": None, "drawn": 0, "busy": False, "expect": None, "log": []}

def _diag(msg):
    """Jurnal pentru depanare (ultimele 30 de linii, vizibile si in /api/live/status)."""
    logger.info(f"Live: {msg}")
    _live["log"] = (_live["log"] + [time.strftime("%H:%M:%S ") + msg])[-30:]

def _state():
    from modules.core.state import state
    return state

def _pm():
    from modules.core import pattern_manager
    return pattern_manager

def _wrap(d):
    return ((d + math.pi) % TAU + TAU) % TAU - math.pi

# ── conversie desen -> coordonate masa (unghi continuu, fara rotiri inutile) ──
def to_theta_rho(points, start_theta, start_rho):
    """points: [[x, y], ...] normalizate (-1..1, y in jos ca pe canvas).
    Porneste din pozitia curenta a bilei (linie dreapta pana la inceputul liniei)."""
    cur = (start_rho * math.cos(start_theta), start_rho * math.sin(start_theta))
    path = [cur] + [(max(-1.0, min(1.0, float(x))), max(-1.0, min(1.0, float(y)))) for x, y in points]
    dense = [path[0]]
    for a, b in zip(path, path[1:]):
        n = max(1, math.ceil(math.hypot(b[0] - a[0], b[1] - a[1]) / STEP))
        dense += [(a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n) for k in range(1, n + 1)]
    out, prev = [], start_theta
    in_center = False
    for x, y in dense[1:]:
        r = min(1.0, math.hypot(x, y))
        if r < CENTER:
            if not in_center:
                out.append((prev, 0.0)); in_center = True
            continue
        t = prev + _wrap(math.atan2(y, x) - prev)
        if in_center:
            out.append((t, 0.0)); in_center = False        # rotirea se face in centru exact
        out.append((t, r)); prev = t
    return out

# ── lumini si muzica ──
def _lights_playing():
    s = _state(); lc = getattr(s, "led_controller", None)
    if not lc: return
    try:
        lc.set_power(1); lc.effect_playing(getattr(s, "dw_led_playing_effect", None))
    except Exception as e:
        logger.debug(f"live leds: {e}")

def _lights_idle():
    s = _state(); lc = getattr(s, "led_controller", None)
    if not lc: return
    try:
        lc.effect_idle(getattr(s, "dw_led_idle_effect", None))
    except Exception as e:
        logger.debug(f"live leds idle: {e}")

def _music_loop():
    """Muzica merge cat timp modul e activ (ca la un model)."""
    while _live["active"]:
        try:
            if not audio.get_status()["playing"] and audio.list_audio_files():
                t = audio._next_track()
                if t: audio.play_file(t)
            if time.time() - _live["last"] > IDLE_OFF_S:
                logger.info("Live: inactiv de 10 minute, opresc modul")
                _deactivate()
                break
        except Exception as e:
            logger.debug(f"live music: {e}")
        time.sleep(2)

# ── miscare ──
async def _runner():
    s = _state(); pm = _pm()
    try:
        while _live["active"] and _live["queue"]:
            t, r = _live["queue"].pop(0)
            _live["busy"] = True
            s.stop_requested = False
            await pm.move_polar(t, r, _live["speed"] or s.speed)
            _live["drawn"] += 1
            _live["expect"] = (getattr(s, "machine_x", None), getattr(s, "machine_y", None), s.current_theta, s.current_rho)
    except Exception as e:
        logger.warning(f"Live: miscare oprita: {e}")
        _live["queue"].clear()
    finally:
        _live["busy"] = False
        _live["task"] = None

def _deactivate():
    _live["active"] = False
    _live["queue"].clear()
    audio._sync_state["started_by_sync"] = False
    audio.stop_playback()
    _lights_idle()

def _check_ready():
    s = _state()
    if not (s.conn.is_connected() if getattr(s, "conn", None) else False):
        raise HTTPException(400, "Masa nu e conectata")
    if getattr(s, "is_homing", False):
        raise HTTPException(409, "Masa face homing, asteapta putin")
    if getattr(s, "machine_x", None) is None:
        raise HTTPException(409, "Pozitia bilei e necunoscuta: fa Home din Control")

# ── API ──
class StartReq(BaseModel):
    speed: float | None = None

class StrokeReq(BaseModel):
    points: list
    speed: float | None = None

@router.post("/start")
async def api_start(r: StartReq):
    _check_ready()
    s = _state()
    try:                                                     # o alarma in curs se anuleaza
        from modules.routines import routines
        if routines._active.get("name"):
            await asyncio.get_event_loop().run_in_executor(None, routines.cancel)
    except Exception:
        pass
    if s.current_playing_file:                               # un model in curs se opreste
        await _pm().stop_actions()
    _live.update(active=True, last=time.time(), speed=r.speed or _live["speed"] or s.speed)
    _lights_playing()
    if not (_live["music_thread"] and _live["music_thread"].is_alive()):
        _live["music_thread"] = threading.Thread(target=_music_loop, daemon=True)
        _live["music_thread"].start()
    return {"success": True, "speed": _live["speed"]}

@router.post("/stroke")
async def api_stroke(r: StrokeReq):
    if not _live["active"]:
        raise HTTPException(409, "Modul Live nu e pornit")
    _check_ready()
    s = _state()
    if s.current_playing_file:
        raise HTTPException(409, "Masa ruleaza un model")
    if r.speed:
        _live["speed"] = r.speed
    pts = [p for p in r.points if isinstance(p, (list, tuple)) and len(p) == 2]
    if not pts:
        raise HTTPException(400, "Linie goala")
    exp = _live["expect"]
    mx, my = getattr(s, "machine_x", None), getattr(s, "machine_y", None)
    if exp and not _live["queue"] and not _live["busy"] and None not in (exp[0], exp[1], mx, my):
        dx, dy = abs(mx - exp[0]), abs(my - exp[1])
        if dx > 0.05 or dy > 0.05 or abs(s.current_theta - exp[2]) > 1e-3:
            _diag(f"ATENTIE pozitia tinuta minte s-a schimbat intre linii: X {exp[0]:.2f}->{mx:.2f}, "
                  f"Y {exp[1]:.2f}->{my:.2f}, theta {exp[2]:.3f}->{s.current_theta:.3f}")
    # continuam de unde se va afla bila dupa ce termina ce are deja in coada
    t0, r0 = _live["queue"][-1] if _live["queue"] else (s.current_theta, s.current_rho)
    _diag(f"linie {len(pts)} puncte, pornesc de la theta={t0:.3f} rho={r0:.3f} "
          f"(X={getattr(s, 'machine_x', None)} Y={getattr(s, 'machine_y', None)}), viteza={_live['speed'] or s.speed}")
    _live["queue"] += to_theta_rho(pts, t0, r0)
    _live["last"] = time.time()
    if not _live["task"]:
        _live["task"] = asyncio.create_task(_runner())
    return {"success": True, "queued": len(_live["queue"])}

@router.post("/center")
async def api_center():
    """Bila merge in centru pe o linie dreapta (de-a lungul razei)."""
    if not _live["active"]:
        raise HTTPException(409, "Modul Live nu e pornit")
    _check_ready()
    s = _state()
    t0, r0 = _live["queue"][-1] if _live["queue"] else (s.current_theta, s.current_rho)
    if r0 > 0.001:
        n = max(1, math.ceil(r0 / STEP))
        _live["queue"] += [(t0, r0 * (1 - k / n)) for k in range(1, n + 1)]
    _live["last"] = time.time()
    _diag(f"bila in centru de la theta={t0:.3f} rho={r0:.3f}")
    if not _live["task"]:
        _live["task"] = asyncio.create_task(_runner())
    return {"success": True}

@router.post("/stop")
async def api_stop():
    _deactivate()
    return {"success": True}

@router.get("/status")
async def api_status():
    s = _state()
    t, r = s.current_theta or 0, s.current_rho or 0
    return {"active": _live["active"], "speed": _live["speed"] or s.speed, "default_speed": s.speed,
            "queued": len(_live["queue"]), "moving": _live["busy"] or bool(_live["queue"]),
            "ball": [r * math.cos(t), r * math.sin(t)], "table_busy": bool(s.current_playing_file),
            "log": _live["log"][-10:]}
