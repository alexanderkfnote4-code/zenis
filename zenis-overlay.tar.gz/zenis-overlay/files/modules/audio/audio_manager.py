"""ZeNis Audio: Bluetooth (bluetoothctl) + redare prin PipeWire-ul utilizatorului."""
import logging, os, pwd, re, shutil, signal, subprocess, threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

def _audio_user():
    name = os.environ.get("ZENIS_AUDIO_USER")
    try:
        return pwd.getpwnam(name) if name else pwd.getpwuid(1000)
    except KeyError:
        return pwd.getpwuid(os.getuid())

try:
    _U = _audio_user()
except Exception:
    _U = pwd.getpwuid(os.getuid())
AUDIO_DIR = Path(_U.pw_dir) / "zenis-audio"
try:
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    os.chown(AUDIO_DIR, _U.pw_uid, _U.pw_gid)
except Exception as e:
    logger.warning(f"audio dir: {e}")

_MAC = re.compile(r"^([0-9A-F]{2}[:-]){5}[0-9A-F]{2}$", re.I)
_player: Optional[subprocess.Popen] = None
_current: Optional[str] = None
_volume = 60
_lock = threading.Lock()

def _run(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return "timeout"
    except Exception as e:
        return str(e)

def _user_kw():
    """Pornim procesele direct ca utilizatorul sesiunii de sunet (PipeWire).
    Fara 'sudo -u' ca intermediar: altfel oprirea nimerea sudo, iar player-ul ramanea orfan."""
    env = dict(os.environ, HOME=_U.pw_dir, USER=_U.pw_name, LOGNAME=_U.pw_name,
               XDG_RUNTIME_DIR=f"/run/user/{_U.pw_uid}",
               DBUS_SESSION_BUS_ADDRESS=f"unix:path=/run/user/{_U.pw_uid}/bus")
    kw = {"env": env}
    if os.getuid() == 0 and _U.pw_uid != 0:
        kw.update(user=_U.pw_uid, group=_U.pw_gid,
                  extra_groups=os.getgrouplist(_U.pw_name, _U.pw_gid))
    return kw

def _run_user(cmd, timeout=6):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **_user_kw())
        return (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return "timeout"
    except Exception as e:
        return str(e)

def _ensure_bt():
    _run(["rfkill", "unblock", "bluetooth"], 5)
    _run(["bluetoothctl", "power", "on"], 8)

def _parse_devices(out):
    devs = []
    for line in out.splitlines():
        p = line.strip().split(" ", 2)
        if len(p) >= 3 and p[0] == "Device":
            devs.append({"mac": p[1], "name": p[2]})
    return devs

# ── Bluetooth ────────────────────────────────────────────────────
_scan_proc: Optional[subprocess.Popen] = None

def _start_discovery(seconds=120):
    """Scanare in fundal: BlueZ uita boxele neimperecheate cand scanarea se opreste."""
    global _scan_proc
    if _scan_proc and _scan_proc.poll() is None:
        return
    _scan_proc = subprocess.Popen(["bluetoothctl", "--timeout", str(seconds), "scan", "on"],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                  start_new_session=True)

def _stop_discovery():
    global _scan_proc
    if _scan_proc and _scan_proc.poll() is None:
        try: os.killpg(_scan_proc.pid, signal.SIGTERM)
        except Exception: pass
    _scan_proc = None
    _run(["bluetoothctl", "scan", "off"], 5)

def _info(mac):
    return _run(["bluetoothctl", "info", mac], 8)

def scan_bluetooth(duration: int = 10):
    import time
    _ensure_bt()
    _stop_discovery()
    _start_discovery(120)          # ramane activa si dupa ce raspundem
    time.sleep(duration)
    paired = {d["mac"] for d in _parse_devices(_run(["bluetoothctl", "devices", "Paired"]))}
    devs = []
    for d in _parse_devices(_run(["bluetoothctl", "devices"])):
        if _MAC.match(d["name"].strip()):
            continue
        d["paired"] = d["mac"] in paired
        devs.append(d)
    devs.sort(key=lambda d: (not d["paired"], d["name"].lower()))
    return devs

def _wait(cond, seconds):
    import time
    for _ in range(int(seconds * 2)):
        if cond():
            return True
        time.sleep(0.5)
    return cond()

def _bt_sink_id(name):
    """Cauta in wpctl iesirea de sunet a boxei; intoarce id-ul sau None."""
    out = _run_user(["wpctl", "status"], 6)
    sec = out.split("Sinks:", 1)[1].split("Sources:", 1)[0] if "Sinks:" in out else ""
    key = name.split()[0].lower() if name else ""
    for line in sec.splitlines():
        m = re.search(r"(\d+)\.\s+(.+?)\s+\[vol", line)
        if m and (key and key in m.group(2).lower() or "bluez" in m.group(2).lower()):
            return m.group(1)
    return None

def pair_bluetooth(mac: str):
    _ensure_bt()
    info = _info(mac)
    name = (re.search(r"Name: (.+)", info) or re.search(r"Alias: (.+)", info))
    name = name.group(1).strip() if name else mac
    if "Paired: yes" not in info:
        # boxa trebuie sa fie "vazuta" chiar acum -> tinem scanarea pornita
        _start_discovery(120)
        if not _wait(lambda: mac in _run(["bluetoothctl", "devices"], 5), 15):
            return {"success": False, "mac": mac,
                    "message": "Boxa nu e vizibila. Pune-o in modul pairing (si opreste Bluetooth-ul pe telefon), apoi Scaneaza din nou."}
        out = _run(["bluetoothctl", "--agent", "NoInputNoOutput", "--timeout", "20", "pair", mac], 24)
        if "Paired: yes" not in _info(mac):
            logger.warning(f"pair {mac}: {out[-300:]}")
            return {"success": False, "mac": mac,
                    "message": "Imperecherea a esuat. Pune boxa in pairing si incearca din nou."}
    _run(["bluetoothctl", "trust", mac], 8)
    _stop_discovery()               # scanarea activa strica sunetul
    _run(["bluetoothctl", "--timeout", "15", "connect", mac], 18)
    if not _wait(lambda: _connected(mac), 6):
        return {"success": False, "mac": mac,
                "message": "Imperecheat, dar conexiunea audio nu s-a deschis. Verifica sa nu fie conectata la telefon."}
    sink = None
    _wait(lambda: bool(_bt_sink_id(name)), 8)
    sink = _bt_sink_id(name)
    if sink:
        _run_user(["wpctl", "set-default", sink], 5)
        _run_user(["wpctl", "set-volume", sink, f"{_volume/100:.2f}"], 5)
    _bt_cache["dev"] = _read_connected()
    if not sink:
        return {"success": False, "mac": mac,
                "message": "Conectata, dar sistemul de sunet nu a preluat boxa (WirePlumber)."}
    return {"success": True, "mac": mac, "message": f"Conectat la {name}!"}

def _connected(mac):
    return "Connected: yes" in _info(mac)

def disconnect_bluetooth():
    devs = _parse_devices(_run(["bluetoothctl", "devices", "Connected"], 5))
    if not devs:
        return {"success": True, "message": "Niciun dispozitiv conectat"}
    for d in devs:
        _run(["bluetoothctl", "disconnect", d["mac"]], 10)
    _bt_cache["dev"] = None
    return {"success": True, "message": "Deconectat"}

_bt_cache = {"dev": None}
_poller = None

def _read_connected():
    devs = _parse_devices(_run(["bluetoothctl", "devices", "Connected"], 4))
    return f'{devs[0]["name"]} ({devs[0]["mac"]})' if devs else None

def _poll_loop():
    import time
    while True:
        try:
            _bt_cache["dev"] = _read_connected()
        except Exception:
            pass
        time.sleep(5)

def _ensure_poller():
    global _poller
    if _poller is None:
        _poller = threading.Thread(target=_poll_loop, daemon=True)
        _poller.start()

def get_connected_device():
    _ensure_poller()
    return _bt_cache["dev"]

# ── Redare ───────────────────────────────────────────────────────
def _kill():
    global _player
    if _player and _player.poll() is None:
        try:
            os.killpg(_player.pid, signal.SIGTERM)
            _player.wait(timeout=3)
        except Exception:
            try: os.killpg(_player.pid, signal.SIGKILL)
            except Exception: pass
    _player = None
    # plasa de siguranta: niciun player nu are voie sa ruleze in continuare un fisier ZeNis
    try:
        subprocess.run(["pkill", "-f", str(AUDIO_DIR)], capture_output=True, timeout=3)
    except Exception:
        pass

def play_file(filename: str):
    global _player, _current
    path = AUDIO_DIR / Path(filename).name
    if not path.exists():
        return {"success": False, "message": "Fisier negasit"}
    if shutil.which("pw-play"):
        cmd = ["pw-play", str(path)]
    elif shutil.which("mpg123") and path.suffix.lower() == ".mp3":
        cmd = ["mpg123", "-q", "-o", "pulse", str(path)]
    else:
        return {"success": False, "message": "Lipseste player-ul. Ruleaza: sudo apt install pipewire-bin mpg123"}
    with _lock:
        _kill()
        _player = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, **_user_kw(),
                                   stderr=subprocess.DEVNULL, start_new_session=True)
        _current = path.name
    return {"success": True, "playing": path.name}

def stop_playback():
    global _current
    with _lock:
        _kill(); _current = None
    try:
        _sync_state["started_by_sync"] = False
        _sync_state["suppress"] = _table_active()   # oprit manual cat masa merge -> nu reporni
    except NameError:
        pass
    return {"success": True}

def set_volume(vol: int):
    global _volume
    _volume = max(0, min(100, int(vol)))
    _run_user(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{_volume/100:.2f}"], 5)
    return {"success": True, "volume": _volume}

def list_audio_files():
    exts = {".mp3", ".wav", ".ogg", ".flac", ".aac"}
    return sorted(f.name for f in AUDIO_DIR.iterdir() if f.suffix.lower() in exts)

def get_status():
    try: _ensure_sync_thread()
    except NameError: pass
    playing = _player is not None and _player.poll() is None
    return {"playing": playing, "current_file": _current if playing else None,
            "bt_device": get_connected_device(), "volume": _volume, "files": list_audio_files(),
            "sync": dict(_sync)}


# ── Muzica sincronizata cu masa ──────────────────────────────────
# Porneste muzica cand masa deseneaza, o opreste cand masa e in pauza
# (manual sau program "Still Sands") ori s-a oprit.
import json, random, time as _time
_SETTINGS = AUDIO_DIR / "settings.json"
_sync = {"enabled": False, "shuffle": False}
_sync_state = {"started_by_sync": False, "suppress": False, "inactive_since": None,
               "queue": [], "thread": None}
_IDLE_GRACE = 30   # secunde de inactivitate pana opresc muzica (pauzele dintre modele)
_session = {"follow": False}   # rutina Good Morning: muzica urmeaza masa chiar daca sincronizarea e oprita

def _load_sync():
    try:
        _sync.update({k: bool(v) for k, v in json.loads(_SETTINGS.read_text()).items() if k in _sync})
    except Exception:
        pass

def _save_sync():
    try:
        _SETTINGS.write_text(json.dumps(_sync))
    except Exception as e:
        logger.warning(f"sync settings: {e}")

def _table_active():
    try:
        from modules.core.state import state
        from modules.core.pattern_manager import is_in_scheduled_pause_period
        return bool(state.current_playing_file) and not state.pause_requested \
            and not is_in_scheduled_pause_period()
    except Exception:
        return False

def _next_track():
    files = list_audio_files()
    if not files:
        return None
    q = _sync_state["queue"]
    q[:] = [f for f in q if f in files]
    if not q:
        q.extend(random.sample(files, len(files)) if _sync["shuffle"] else files)
    return q.pop(0)

def _sync_loop():
    while True:
        try:
            active = _table_active()
            now = _time.time()
            playing = _player is not None and _player.poll() is None
            if active:
                _sync_state["inactive_since"] = None
            elif _sync_state["inactive_since"] is None:
                _sync_state["inactive_since"] = now
            idle_long = (not active and _sync_state["inactive_since"] is not None
                         and now - _sync_state["inactive_since"] >= _IDLE_GRACE)
            if idle_long:
                _sync_state["suppress"] = False        # la urmatoarea pornire a mesei reia muzica
                _session["follow"] = False
            follow = _sync["enabled"] or _session["follow"]
            if follow and active and not playing and not _sync_state["suppress"]:
                track = _next_track()
                if track and play_file(track).get("success"):
                    _sync_state["started_by_sync"] = True
            elif playing and _sync_state["started_by_sync"] and (idle_long or not follow):
                with _lock:
                    _kill()
                _sync_state["started_by_sync"] = False
        except Exception as e:
            logger.debug(f"sync loop: {e}")
        _time.sleep(2)

def _ensure_sync_thread():
    if _sync_state["thread"] is None:
        _load_sync()
        _sync_state["thread"] = threading.Thread(target=_sync_loop, daemon=True)
        _sync_state["thread"].start()

def get_sync():
    _ensure_sync_thread()
    return dict(_sync)

def set_sync(enabled=None, shuffle=None):
    _ensure_sync_thread()
    if enabled is not None:
        _sync["enabled"] = bool(enabled)
    if shuffle is not None:
        _sync["shuffle"] = bool(shuffle)
        _sync_state["queue"].clear()
    _save_sync()
    return dict(_sync)

# Sincronizarea muzicii porneste odata cu serverul (inainte pornea doar la prima
# deschidere a paginii Audio, deci dupa o repornire muzica nu urma masa).
_ensure_sync_thread()
