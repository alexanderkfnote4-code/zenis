"""ZeNis LED Override: comutatorul care deblocheaza controlul manual al luminilor.

Cat e ACTIV:   luminile raspund doar comenzilor tale; Dune Weaver nu le mai reseteaza singur
               (nici la sfarsitul unui model, nici la pauza/reluare).
Cand se OPRESTE (de tine sau automat): revine tot ce era inainte - scena salvata pentru
               'ruleaza' sau 'repaus', luminozitatea, viteza, intensitatea si aprinderea.
Automat se opreste cand: incepe o forma noua, porneste o rutina (Good Morning/Night) sau modul Live.
"""
import asyncio, logging, threading, time
from fastapi import APIRouter
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter()
POLL_S = 0.5

_ov = {"active": False, "snap": None, "file": None, "thread": None, "reason": None}
_lock = threading.RLock()

def _state():
    from modules.core.state import state
    return state

def _led():
    s = _state()
    lc = getattr(s, "led_controller", None)
    return lc if lc and getattr(s, "led_provider", None) == "dw_leds" else None

# ── blocam resetarile automate cat e activ ──
def _block(lc, on):
    names = ("effect_idle", "effect_playing", "effect_idle_async", "effect_playing_async")
    if on:
        async def _noop_async(*a, **k): return True
        for n in names:
            lc.__dict__[n] = _noop_async if n.endswith("_async") else (lambda *a, **k: True)
    else:
        for n in names:
            lc.__dict__.pop(n, None)

def _status(lc):
    try:
        return lc.check_status() or {}
    except Exception:
        return {}

def _ctl(lc):
    try:
        return lc.get_controller()
    except Exception:
        return None

# ── activare / dezactivare ──
def activate():
    with _lock:
        if _ov["active"]:
            return True
        lc = _led()
        if not lc:
            return False
        s = _state()
        st = _status(lc)
        _ov["snap"] = {"brightness": getattr(s, "dw_led_brightness", 35), "speed": getattr(s, "dw_led_speed", None),
                       "intensity": getattr(s, "dw_led_intensity", None), "power": st.get("power_on")}
        _ov["file"] = s.current_playing_file
        _ov["reason"] = None
        _block(lc, True)
        _ov["active"] = True
        if not (_ov["thread"] and _ov["thread"].is_alive()):
            _ov["thread"] = threading.Thread(target=_watch, daemon=True)
            _ov["thread"].start()
        logger.info("LED override: pornit")
        return True

def deactivate(reason="manual"):
    with _lock:
        if not _ov["active"]:
            return
        lc = _led()
        snap, s = _ov["snap"] or {}, _state()
        _ov["active"] = False
        _ov["reason"] = reason
        if lc:
            _block(lc, False)
            c = _ctl(lc)
            try:                                              # valorile salvate inapoi in setari
                if snap.get("brightness") is not None: s.dw_led_brightness = snap["brightness"]
                if snap.get("speed") is not None: s.dw_led_speed = snap["speed"]
                if snap.get("intensity") is not None: s.dw_led_intensity = snap["intensity"]
                s.save()
            except Exception as e:
                logger.warning(f"LED override: salvare setari: {e}")
            try:
                if c and snap.get("speed") is not None: c.set_speed(snap["speed"])
                if c and snap.get("intensity") is not None: c.set_intensity(snap["intensity"])
            except Exception as e:
                logger.debug(f"LED override: viteza/intensitate: {e}")
            try:                                              # scena salvata: 'ruleaza' sau 'repaus'
                if s.current_playing_file:
                    lc.effect_playing(getattr(s, "dw_led_playing_effect", None))
                else:
                    lc.effect_idle(getattr(s, "dw_led_idle_effect", None))
            except Exception as e:
                logger.warning(f"LED override: scena salvata: {e}")
            try:
                if c and snap.get("brightness") is not None: c.set_brightness(int(round(snap["brightness"])))
                if snap.get("power") is not None: lc.set_power(1 if snap["power"] else 0)
            except Exception as e:
                logger.debug(f"LED override: luminozitate/aprindere: {e}")
        logger.info(f"LED override: oprit ({reason})")

# ── supraveghere: forma noua / rutina / live => se opreste singur ──
def _other_takes_over():
    try:
        from modules.routines import routines
        if routines._active.get("name"):
            return "rutina"
    except Exception:
        pass
    try:
        from modules.live import live
        if live._live.get("active"):
            return "live"
    except Exception:
        pass
    return None

def _watch():
    while True:
        try:
            if _ov["active"]:
                cur = _state().current_playing_file
                if cur != _ov["file"]:
                    if cur:
                        deactivate("forma noua")
                    else:
                        _ov["file"] = None                      # modelul s-a terminat; urmatorul il opreste
                else:
                    other = _other_takes_over()
                    if other:
                        deactivate(other)
        except Exception as e:
            logger.debug(f"LED override watch: {e}")
        time.sleep(POLL_S)

# ── API ──
class OverrideReq(BaseModel):
    active: bool

@router.get("")
async def api_get():
    return {"active": _ov["active"], "reason": _ov["reason"], "available": _led() is not None}

@router.post("")
async def api_set(r: OverrideReq):
    loop = asyncio.get_event_loop()
    if r.active:
        ok = await loop.run_in_executor(None, activate)
        return {"active": _ov["active"], "available": ok}
    await loop.run_in_executor(None, deactivate, "manual")
    return {"active": False, "available": _led() is not None}
