#!/bin/bash
DW="$HOME/dune-weaver"; P="$(cd "$(dirname "$0")" && pwd)"; U="$USER"; UID_=$(id -u)
echo "-> 1/6 Pachete audio (pw-play, mpg123)"
sudo apt-get install -y -qq pipewire-bin mpg123 >/dev/null && echo "   ok"
echo "-> 2/6 Deblochez Bluetooth"
sudo rfkill unblock bluetooth
echo "-> 3/6 Bluetooth clasic (fara BLE) - necesar pentru sunet pe boxe"
if grep -qE "^\s*#?\s*ControllerMode" /etc/bluetooth/main.conf; then
  sudo sed -i -E 's/^\s*#?\s*ControllerMode\s*=.*/ControllerMode = bredr/' /etc/bluetooth/main.conf
else
  sudo sed -i '/^\[General\]/a ControllerMode = bredr' /etc/bluetooth/main.conf
fi
sudo systemctl restart bluetooth; sleep 2; bluetoothctl power on >/dev/null 2>&1
echo "-> 4/6 Sesiune audio pornita permanent pentru $U"
sudo loginctl enable-linger "$U"
XDG_RUNTIME_DIR=/run/user/$UID_ systemctl --user enable --now pipewire wireplumber >/dev/null 2>&1
XDG_RUNTIME_DIR=/run/user/$UID_ systemctl --user enable --now pipewire-pulse >/dev/null 2>&1
echo "-> 5/6 Modul audio ZeNis (cu backup)"
rm -rf /tmp/zenis-audio-backup && cp -r "$DW/modules/audio" /tmp/zenis-audio-backup 2>/dev/null
rm -rf "$DW/modules/audio" && cp -r "$P/modules/audio" "$DW/modules/"
mkdir -p "$HOME/zenis-audio"
echo "-> 6/6 Restart ZeNis"
sudo systemctl restart dune-weaver
OK=0; for i in $(seq 1 30); do sleep 1; curl -s -m 2 http://localhost/api/audio/status >/dev/null && { OK=1; break; }; done
if [ "$OK" != "1" ]; then
  echo "!!! Serverul nu a pornit - revin la modulul audio anterior"
  sudo journalctl -u dune-weaver -n 25 --no-pager | tail -25
  if [ -d /tmp/zenis-audio-backup ]; then rm -rf "$DW/modules/audio"; cp -r /tmp/zenis-audio-backup "$DW/modules/audio"; fi
  sudo systemctl restart dune-weaver
  echo "!!! Revenit. Trimite-mi textul de mai sus."; exit 1
fi
echo "=== Verificare ==="
rfkill list bluetooth | grep -i soft
grep "^ControllerMode" /etc/bluetooth/main.conf
command -v pw-play >/dev/null && echo "pw-play: ok" || echo "pw-play: LIPSA"
curl -s -m 5 http://localhost/api/audio/status && echo && echo "GATA - pune boxa in pairing si apasa Scaneaza in tab-ul Audio"
