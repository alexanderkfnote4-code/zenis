#!/bin/bash
DW="$HOME/dune-weaver"; P="$(cd "$(dirname "$0")" && pwd)"; U="$USER"; UID_=$(id -u)
echo "-> 1/6 Pachete audio (pw-play, mpg123)"
sudo apt-get install -y -qq pipewire-bin mpg123 >/dev/null && echo "   ok"
echo "-> 2/6 Deblochez Bluetooth"
sudo rfkill unblock bluetooth
echo "-> 3/6 Bluetooth clasic (fara BLE) - necesar pentru sunet pe boxe"
if grep -qE "^\s*#?\s*ControllerMode" /etc/bluetooth/main.conf; then
  sudo sed -i -E 's/^\s*#?\s*ControllerMode\s*=.*/ControllerMode = bredr/' /etc/bluetooth/main.conf
else
  sudo sed -i '/^\[General\]/a ControllerMode = bredr' /etc/bluetooth/main.conf
fi
sudo systemctl restart bluetooth; sleep 2; bluetoothctl power on >/dev/null 2>&1
echo "-> 4/6 Sesiune audio pornita permanent pentru $U"
sudo loginctl enable-linger "$U"
XDG_RUNTIME_DIR=/run/user/$UID_ systemctl --user enable --now pipewire wireplumber >/dev/null 2>&1
XDG_RUNTIME_DIR=/run/user/$UID_ systemctl --user enable --now pipewire-pulse >/dev/null 2>&1
echo "-> 5/6 Modul audio ZeNis"
rm -rf "$DW/modules/audio" && cp -r "$P/modules/audio" "$DW/modules/"
mkdir -p "$HOME/zenis-audio"
echo "-> 6/6 Restart ZeNis"
sudo systemctl restart dune-weaver; sleep 4
echo "=== Verificare ==="
rfkill list bluetooth | grep -i soft
grep "^ControllerMode" /etc/bluetooth/main.conf
command -v pw-play >/dev/null && echo "pw-play: ok" || echo "pw-play: LIPSA"
curl -s -m 5 http://localhost/api/audio/status && echo && echo "GATA - pune boxa in pairing si apasa Scaneaza in tab-ul Audio"
