"""ZeNis Audio: Bluetooth (bluetoothctl) + redare prin PipeWire-ul utilizatorului."""
import logging, os, pwd, re, shutil, signal, subprocess, threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

def _audio_user():
    name = os.environ.get("ZENIS_AUDIO_USER")
    try:
        return pwd.getpwnam(name) if name else pwd.getpwuid(1000)
    except KeyError:
        return pwd.getpwuid(os.getuid())

_U = _audio_user()
AUDIO_DIR = Path(_U.pw_dir) / "zenis-audio"
AUDIO_DIR.mkdir(parents=True, exist_ok=True)
try:
    os.chown(AUDIO_DIR, _U.pw_uid, _U.pw_gid)
except PermissionError:
    pass

_MAC = re.compile(r"^([0-9A-F]{2}[:-]){5}[0-9A-F]{2}$", re.I)
_player: Optional[subprocess.Popen] = None
_current: Optional[str] = None
_volume = 60
_lock = threading.Lock()

def _run(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return "timeout"
    except Exception as e:
        return str(e)

def _as_user(cmd):
    """Ruleaza comanda in sesiunea audio (PipeWire) a utilizatorului."""
    env = [f"XDG_RUNTIME_DIR=/run/user/{_U.pw_uid}",
           f"DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{_U.pw_uid}/bus"]
    if os.getuid() == _U.pw_uid:
        return ["env", *env, *cmd]
    return ["sudo", "-u", _U.pw_name, "env", *env, *cmd]

def _ensure_bt():
    _run(["rfkill", "unblock", "bluetooth"], 5)
    _run(["bluetoothctl", "power", "on"], 8)

def _parse_devices(out):
    devs = []
    for line in out.splitlines():
        p = line.strip().split(" ", 2)
        if len(p) >= 3 and p[0] == "Device":
            devs.append({"mac": p[1], "name": p[2]})
    return devs

# ── Bluetooth ────────────────────────────────────────────────────
def scan_bluetooth(duration: int = 10):
    _ensure_bt()
    _run(["bluetoothctl", "--timeout", str(duration), "scan", "on"], duration + 5)
    paired = {d["mac"] for d in _parse_devices(_run(["bluetoothctl", "devices", "Paired"]))}
    devs = []
    for d in _parse_devices(_run(["bluetoothctl", "devices"])):
        if _MAC.match(d["name"].strip()):      # dispozitive fara nume = zgomot
            continue
        d["paired"] = d["mac"] in paired
        devs.append(d)
    devs.sort(key=lambda d: (not d["paired"], d["name"].lower()))
    return devs

def _connected(mac):
    return "Connected: yes" in _run(["bluetoothctl", "info", mac], 8)

def pair_bluetooth(mac: str):
    _ensure_bt()
    out = _run(["bluetoothctl", "--timeout", "20", "pair", mac], 25)
    if "Failed" in out and "AlreadyExists" not in out and "Paired: yes" not in _run(["bluetoothctl", "info", mac]):
        logger.warning(f"pair {mac}: {out[-200:]}")
    _run(["bluetoothctl", "trust", mac], 8)
    out = _run(["bluetoothctl", "--timeout", "20", "connect", mac], 25)
    if _connected(mac):
        _run(_as_user(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{_volume/100:.2f}"]), 5)
        return {"success": True, "mac": mac, "message": "Conectat!"}
    hint = " Pune boxa in modul pairing si incearca din nou." if "not available" in out or "Failed" in out else ""
    return {"success": False, "mac": mac, "message": "Conectarea a esuat." + hint}

def disconnect_bluetooth():
    mac = get_connected_device()
    if not mac:
        return {"success": True, "message": "Niciun dispozitiv conectat"}
    _run(["bluetoothctl", "disconnect", mac], 10)
    return {"success": True, "message": f"Deconectat {mac}"}

def get_connected_device():
    devs = _parse_devices(_run(["bluetoothctl", "devices", "Connected"], 5))
    return f'{devs[0]["name"]} ({devs[0]["mac"]})' if devs else None

# ── Redare ───────────────────────────────────────────────────────
def _kill():
    global _player
    if _player and _player.poll() is None:
        try:
            os.killpg(_player.pid, signal.SIGTERM)
            _player.wait(timeout=3)
        except Exception:
            try: os.killpg(_player.pid, signal.SIGKILL)
            except Exception: pass
    _player = None

def play_file(filename: str):
    global _player, _current
    path = AUDIO_DIR / Path(filename).name
    if not path.exists():
        return {"success": False, "message": "Fisier negasit"}
    if shutil.which("pw-play"):
        cmd = ["pw-play", str(path)]
    elif shutil.which("mpg123") and path.suffix.lower() == ".mp3":
        cmd = ["mpg123", "-q", "-o", "pulse", str(path)]
    else:
        return {"success": False, "message": "Lipseste player-ul. Ruleaza: sudo apt install pipewire-bin mpg123"}
    with _lock:
        _kill()
        _player = subprocess.Popen(_as_user(cmd), stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, start_new_session=True)
        _current = path.name
    return {"success": True, "playing": path.name}

def stop_playback():
    global _current
    with _lock:
        _kill(); _current = None
    return {"success": True}

def set_volume(vol: int):
    global _volume
    _volume = max(0, min(100, int(vol)))
    _run(_as_user(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{_volume/100:.2f}"]), 5)
    return {"success": True, "volume": _volume}

def list_audio_files():
    exts = {".mp3", ".wav", ".ogg", ".flac", ".aac"}
    return sorted(f.name for f in AUDIO_DIR.iterdir() if f.suffix.lower() in exts)

def get_status():
    playing = _player is not None and _player.poll() is None
    return {"playing": playing, "current_file": _current if playing else None,
            "bt_device": get_connected_device(), "volume": _volume, "files": list_audio_files()}
