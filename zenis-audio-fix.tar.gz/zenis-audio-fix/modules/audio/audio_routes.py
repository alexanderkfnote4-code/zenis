import asyncio, shutil
from pathlib import Path
from fastapi import APIRouter, HTTPException, UploadFile, File
from pydantic import BaseModel
from modules.audio.audio_manager import (
    scan_bluetooth, pair_bluetooth, disconnect_bluetooth,
    get_status, list_audio_files, play_file, stop_playback, set_volume, AUDIO_DIR)
router = APIRouter()
class PairReq(BaseModel): mac: str
class PlayReq(BaseModel): filename: str
class VolReq(BaseModel): volume: int
@router.get("/bluetooth/scan")
async def api_scan(): return {"devices": await asyncio.get_event_loop().run_in_executor(None, scan_bluetooth, 10)}
@router.post("/bluetooth/pair")
async def api_pair(req: PairReq): return await asyncio.get_event_loop().run_in_executor(None, pair_bluetooth, req.mac)
@router.post("/bluetooth/disconnect")
async def api_disconnect(): return disconnect_bluetooth()
@router.get("/status")
async def api_status(): return get_status()
@router.post("/play")
async def api_play(req: PlayReq):
    r = play_file(req.filename)
    if not r["success"]: raise HTTPException(400, r["message"])
    return r
@router.post("/stop")
async def api_stop(): return stop_playback()
@router.post("/volume")
async def api_volume(req: VolReq): return set_volume(req.volume)
@router.get("/files")
async def api_files(): return {"files": list_audio_files()}
@router.post("/upload")
async def api_upload(file: UploadFile = File(...)):
    if Path(file.filename).suffix.lower() not in {".mp3",".wav",".ogg",".flac",".aac"}: raise HTTPException(400, "Format nepermis")
    dest = AUDIO_DIR / Path(file.filename).name
    with dest.open("wb") as f: shutil.copyfileobj(file.file, f)
    try:
        import os
        st = AUDIO_DIR.stat(); os.chown(dest, st.st_uid, st.st_gid)
    except Exception: pass
    return {"success": True, "filename": file.filename}
@router.delete("/files/{filename}")
async def api_delete(filename: str):
    p = AUDIO_DIR / Path(filename).name
    if not p.exists(): raise HTTPException(404, "Negăsit")
    p.unlink(); return {"success": True}
