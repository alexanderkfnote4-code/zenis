#!/bin/bash
DW="$HOME/dune-weaver"; P="$(cd "$(dirname "$0")" && pwd)"; U="$USER"; UID_=$(id -u)
export XDG_RUNTIME_DIR=/run/user/$UID_
echo "-> 1/6 Pachete + Bluetooth"
sudo apt-get install -y -qq pipewire-bin mpg123 >/dev/null
sudo rfkill unblock bluetooth
MC=/etc/bluetooth/main.conf
grep -qE "^ControllerMode = bredr" $MC || { sudo sed -i -E '/^\s*#?\s*ControllerMode\s*=/d' $MC; sudo sed -i '/^\[General\]/a ControllerMode = bredr' $MC; }
grep -qE "^TemporaryTimeout" $MC || sudo sed -i '/^\[General\]/a TemporaryTimeout = 300' $MC
sudo systemctl restart bluetooth; sleep 2; bluetoothctl power on >/dev/null 2>&1
echo "-> 2/6 Sesiune sunet permanenta (fara ecran)"
sudo loginctl enable-linger "$U"
mkdir -p ~/.config/wireplumber/wireplumber.conf.d
cat > ~/.config/wireplumber/wireplumber.conf.d/80-bluetooth-headless.conf << 'WP'
wireplumber.profiles = {
  main = {
    monitor.bluez.seat-monitoring = disabled
  }
}
WP
systemctl --user enable --now pipewire wireplumber >/dev/null 2>&1
systemctl --user restart wireplumber
echo "-> 3/6 Backup modul audio curent"
rm -rf /tmp/zenis-audio-backup; mkdir -p /tmp/zenis-audio-backup
cp "$DW"/modules/audio/*.py /tmp/zenis-audio-backup/ 2>/dev/null
echo "-> 4/6 Instalez modulul nou (fisier cu fisier)"
rm -rf "$DW/modules/audio"; mkdir -p "$DW/modules/audio"
cp "$P"/modules/audio/*.py "$DW/modules/audio/"
ls "$DW/modules/audio"
echo "-> 5/6 Test import inainte de restart"
cd "$DW"
if ! sudo .venv/bin/python -c "import modules.audio.audio_routes" 2>/tmp/imp.err; then
  echo "!!! Import esuat:"; tail -5 /tmp/imp.err
  if ls /tmp/zenis-audio-backup/*.py >/dev/null 2>&1; then
    rm -rf "$DW/modules/audio"; mkdir -p "$DW/modules/audio"; cp /tmp/zenis-audio-backup/*.py "$DW/modules/audio/"
    echo "!!! Am pus inapoi modulul vechi"
  fi
  exit 1
fi
# reactivam audio daca fusese comentat
sed -i 's/^# \(from modules.audio import audio_routes\)/\1/; s/^# \(app.include_router(audio_routes\)/\1/' main.py
echo "-> 6/6 Restart ZeNis"
sudo systemctl restart dune-weaver
for i in $(seq 1 40); do sleep 1; curl -sf -m 2 http://localhost/api/audio/status >/dev/null && { echo ">>> ZeNis + AUDIO PORNIT dupa ${i}s"; exit 0; }; done
echo "!!! ZeNis nu raspunde. Ultimele erori:"; sudo journalctl -u dune-weaver -n 20 --no-pager | tail -20
