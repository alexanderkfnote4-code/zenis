#!/bin/bash
set -e
DW="$HOME/dune-weaver"
P="$(cd "$(dirname "$0")" && pwd)"
[ -f "$DW/main.py" ] || { echo "Nu gasesc $DW"; exit 1; }
echo "-> Interfata (build nou)"
rm -f "$DW/static/dist/assets/index-"*.js "$DW/static/dist/assets/index-"*.css
cp "$P/static/dist/assets/"* "$DW/static/dist/assets/"
cp "$P/static/dist/index.html" "$P/static/dist/sw.js" "$P/static/dist/registerSW.js" "$DW/static/dist/"
echo "-> Pagina Deseneaza"
cp "$P/draw.html" "$DW/static/draw.html"
echo "-> Modul audio"
rm -rf "$DW/modules/audio" && cp -r "$P/modules/audio" "$DW/modules/"
cd "$DW"
if ! grep -q "audio_routes" main.py; then
python3 - << 'PY'
lines=open("main.py").read().splitlines()
imp=max(i for i,l in enumerate(lines) if l.startswith("from modules."))
lines.insert(imp+1,"from modules.audio import audio_routes")
app=max(i for i,l in enumerate(lines) if l.startswith("app = FastAPI("))
lines.insert(app+1,'app.include_router(audio_routes.router, prefix="/api/audio", tags=["audio"])') if lines[app].rstrip().endswith(")") else None
open("main.py","w").write("\n".join(lines)+"\n")
PY
grep -q 'include_router(audio_routes' main.py || echo 'app.include_router(audio_routes.router, prefix="/api/audio", tags=["audio"])' >> main.py
fi
sudo systemctl restart dune-weaver
sleep 3
systemctl is-active --quiet dune-weaver && echo "OK - ZeNis ruleaza. Deschide http://$(hostname).local si da refresh (F5)" || { echo "EROARE la pornire:"; sudo journalctl -u dune-weaver -n 15 --no-pager; }
