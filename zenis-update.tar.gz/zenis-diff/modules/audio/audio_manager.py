"""
ZeNis Audio Manager
Bluetooth speaker pairing + local file playback via pygame/mpg123
"""

import asyncio
import json
import logging
import os
import subprocess
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

AUDIO_DIR = Path("/opt/zenis-audio")
AUDIO_DIR.mkdir(exist_ok=True)

_player_proc: Optional[subprocess.Popen] = None
_current_file: Optional[str] = None
_bt_device: Optional[str] = None
_volume: int = 80
_lock = threading.Lock()


# ── Bluetooth helpers ─────────────────────────────────────────────────────────

def _bluetoothctl(commands: list[str], timeout: int = 15) -> str:
    """Run a sequence of bluetoothctl commands and return combined output."""
    cmd = "\n".join(commands) + "\nquit\n"
    try:
        result = subprocess.run(
            ["bluetoothctl"],
            input=cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return "timeout"
    except Exception as e:
        return str(e)


def scan_bluetooth(duration: int = 8) -> list[dict]:
    """Scan for nearby Bluetooth devices. Returns list of {mac, name}."""
    try:
        # Power on + scan
        subprocess.run(["bluetoothctl", "power", "on"], capture_output=True, timeout=5)
        proc = subprocess.Popen(
            ["bluetoothctl", "scan", "on"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        import time
        time.sleep(duration)
        proc.terminate()

        # Get discovered devices
        out = _bluetoothctl(["devices"])
        devices = []
        for line in out.splitlines():
            # Format: Device AA:BB:CC:DD:EE:FF Name
            parts = line.strip().split(" ", 2)
            if len(parts) >= 3 and parts[0] == "Device":
                devices.append({"mac": parts[1], "name": parts[2]})
        return devices
    except Exception as e:
        logger.error(f"Bluetooth scan error: {e}")
        return []


def pair_bluetooth(mac: str) -> dict:
    """Pair, trust, and connect a Bluetooth device."""
    global _bt_device
    try:
        out = _bluetoothctl([
            "power on",
            f"pair {mac}",
            f"trust {mac}",
            f"connect {mac}",
        ], timeout=30)

        if "Connection successful" in out or "already connected" in out.lower():
            _bt_device = mac
            # Set as default audio sink via PulseAudio / PipeWire
            _set_bt_sink(mac)
            return {"success": True, "mac": mac, "message": "Conectat cu succes!"}
        else:
            return {"success": False, "mac": mac, "message": out[-300:]}
    except Exception as e:
        return {"success": False, "mac": mac, "message": str(e)}


def disconnect_bluetooth() -> dict:
    """Disconnect current BT device."""
    global _bt_device
    if not _bt_device:
        return {"success": True, "message": "Niciun dispozitiv conectat"}
    try:
        _bluetoothctl([f"disconnect {_bt_device}"])
        mac = _bt_device
        _bt_device = None
        return {"success": True, "message": f"Deconectat {mac}"}
    except Exception as e:
        return {"success": False, "message": str(e)}


def get_connected_device() -> Optional[str]:
    """Return MAC of currently connected BT audio device, or None."""
    return _bt_device


def _set_bt_sink(mac: str):
    """Set Bluetooth speaker as default PulseAudio/PipeWire sink."""
    # Mac format for PA: replaces : with _
    sink_name = f"bluez_sink.{mac.replace(':', '_')}.a2dp_sink"
    try:
        subprocess.run(["pactl", "set-default-sink", sink_name],
                       capture_output=True, timeout=5)
    except Exception:
        pass  # PipeWire may handle this automatically


# ── Playback ──────────────────────────────────────────────────────────────────

def _kill_player():
    global _player_proc
    if _player_proc and _player_proc.poll() is None:
        _player_proc.terminate()
        try:
            _player_proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            _player_proc.kill()
    _player_proc = None


def play_file(filename: str) -> dict:
    """Play an audio file from AUDIO_DIR."""
    global _player_proc, _current_file
    path = AUDIO_DIR / filename
    if not path.exists():
        return {"success": False, "message": "Fișier negăsit"}

    with _lock:
        _kill_player()
        ext = path.suffix.lower()
        try:
            if ext == ".mp3":
                cmd = ["mpg123", "-q", "-f", str(int(_volume * 327)), str(path)]
            elif ext in (".wav", ".ogg", ".flac"):
                cmd = ["aplay", str(path)] if ext == ".wav" else ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(path)]
            else:
                cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(path)]

            _player_proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            _current_file = filename
            return {"success": True, "playing": filename}
        except FileNotFoundError as e:
            return {"success": False, "message": f"Player lipsă: {e}. Instalează: sudo apt install mpg123 ffmpeg"}
        except Exception as e:
            return {"success": False, "message": str(e)}


def stop_playback() -> dict:
    global _current_file
    with _lock:
        _kill_player()
        _current_file = None
    return {"success": True}


def set_volume(vol: int) -> dict:
    """Set system volume 0-100."""
    global _volume
    vol = max(0, min(100, vol))
    _volume = vol
    try:
        subprocess.run(["amixer", "-q", "sset", "Master", f"{vol}%"],
                       capture_output=True, timeout=3)
        return {"success": True, "volume": vol}
    except Exception as e:
        return {"success": False, "message": str(e)}


def get_status() -> dict:
    playing = _player_proc is not None and _player_proc.poll() is None
    return {
        "playing": playing,
        "current_file": _current_file if playing else None,
        "bt_device": _bt_device,
        "volume": _volume,
        "files": list_audio_files(),
    }


def list_audio_files() -> list[str]:
    exts = {".mp3", ".wav", ".ogg", ".flac", ".aac"}
    return sorted(f.name for f in AUDIO_DIR.iterdir() if f.suffix.lower() in exts)
