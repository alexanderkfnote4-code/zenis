#!/bin/bash
# ZeNis installer - aplică peste Dune Weaver existent
set -e

DW="$HOME/dune-weaver"
PATCH="$(cd "$(dirname "$0")" && pwd)"

if [ ! -f "$DW/main.py" ]; then
  echo "❌ Nu găsesc ~/dune-weaver ! Instalează Dune Weaver mai întâi."
  exit 1
fi

echo "→ Copiez fișierele ZeNis..."
cp -r "$PATCH/frontend/src/pages/DrawPage.tsx"  "$DW/frontend/src/pages/"
cp -r "$PATCH/frontend/src/pages/AudioPage.tsx" "$DW/frontend/src/pages/"
cp    "$PATCH/frontend/src/App.tsx"              "$DW/frontend/src/"
cp    "$PATCH/frontend/src/index.css"            "$DW/frontend/src/"
cp    "$PATCH/frontend/src/components/layout/Layout.tsx" "$DW/frontend/src/components/layout/"
cp -r "$PATCH/modules/audio"                    "$DW/modules/"
cp    "$PATCH/main.py"                          "$DW/"

echo "→ Copiez build frontend..."
# Remove old built assets
rm -f "$DW/static/dist/assets/index-"*.js
rm -f "$DW/static/dist/assets/index-"*.css
cp "$PATCH/static/dist/assets/"* "$DW/static/dist/assets/"
cp "$PATCH/static/dist/index.html"   "$DW/static/dist/"
cp "$PATCH/static/dist/sw.js"        "$DW/static/dist/"
cp "$PATCH/static/dist/registerSW.js" "$DW/static/dist/"

echo "→ Restart serviciu..."
sudo systemctl restart dune-weaver

echo ""
echo "✓ ZeNis instalat! Deschide http://$(hostname).local"
