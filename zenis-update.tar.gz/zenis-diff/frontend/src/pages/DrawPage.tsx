/**
 * DrawPage.tsx  —  ZeNis Draw
 * Pune în: frontend/src/pages/DrawPage.tsx
 *
 * Tab separat în navigație. Permite desenarea liberă pe un canvas circular,
 * convertește traseul în coordonate theta-rho și trimite direct la masă
 * sau salvează ca pattern .thr.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Pencil,
  Circle,
  Square,
  Triangle,
  Minus,
  Eraser,
  Trash2,
  Download,
  Play,
  RotateCcw,
} from "lucide-react";

// ── Constants ─────────────────────────────────────────────────────────────────
const SIZE   = 480;   // canvas px
const CX     = SIZE / 2;
const CY     = SIZE / 2;
const R      = SIZE / 2 - 16;
const SAND   = "#C8A97E";
const SAND_DIM = "rgba(200,169,126,0.25)";
const BG     = "#0E0C09";

type Tool = "pen" | "line" | "circle" | "rect" | "triangle" | "text" | "erase";

interface Point { x: number; y: number }
interface Shape {
  type: Tool;
  points?: Point[];
  x0?: number; y0?: number;
  x1?: number; y1?: number;
  x?: number;  y?: number;
  text?: string;
  fontSize?: number;
}

// ── Geometry helpers ──────────────────────────────────────────────────────────
function sampleLine(x0:number,y0:number,x1:number,y1:number,n=60):Point[]{
  return Array.from({length:n},(_, i)=>({x:x0+(x1-x0)*(i/n),y:y0+(y1-y0)*(i/n)}));
}
function sampleArc(cx:number,cy:number,rx:number,ry:number,a0:number,a1:number,n=120):Point[]{
  return Array.from({length:n},(_, i)=>{
    const a=a0+(a1-a0)*(i/(n-1));
    return {x:cx+rx*Math.cos(a),y:cy+ry*Math.sin(a)};
  });
}

function shapeToPoints(s:Shape):Point[]{
  switch(s.type){
    case "pen":    return (s.points||[]).filter((_,i)=>i%2===0);
    case "line":   return sampleLine(s.x0!,s.y0!,s.x1!,s.y1!);
    case "circle": {
      const rx=Math.abs(s.x1!-s.x0!)/2, ry=Math.abs(s.y1!-s.y0!)/2;
      return sampleArc((s.x0!+s.x1!)/2,(s.y0!+s.y1!)/2,rx,ry,0,2*Math.PI);
    }
    case "rect": {
      const x0=Math.min(s.x0!,s.x1!),y0=Math.min(s.y0!,s.y1!);
      const x1=Math.max(s.x0!,s.x1!),y1=Math.max(s.y0!,s.y1!);
      return [...sampleLine(x0,y0,x1,y0),...sampleLine(x1,y0,x1,y1),
              ...sampleLine(x1,y1,x0,y1),...sampleLine(x0,y1,x0,y0)];
    }
    case "triangle": {
      const tx=(s.x0!+s.x1!)/2;
      return [...sampleLine(tx,s.y0!,s.x1!,s.y1!),
              ...sampleLine(s.x1!,s.y1!,s.x0!,s.y1!),
              ...sampleLine(s.x0!,s.y1!,tx,s.y0!)];
    }
    default: return [];
  }
}

function dist2(a:Point,b:Point){ return Math.sqrt((a.x-b.x)**2+(a.y-b.y)**2); }

function shapesToThetaRho(shapes:Shape[]):[number,number][]{
  const all:Point[]=[];
  let cur:Point={x:CX,y:CY};
  for(const s of shapes){
    const pts=shapeToPoints(s);
    if(!pts.length) continue;
    // Travel to nearest endpoint
    let best=0, bd=Infinity;
    pts.forEach((p,i)=>{ const d=dist2(p,cur); if(d<bd){bd=d;best=i;} });
    // Bridge gap smoothly
    const gap=sampleLine(cur.x,cur.y,pts[best].x,pts[best].y,Math.max(4,Math.ceil(bd/4)));
    all.push(...gap);
    const ord=[...pts.slice(best),...pts.slice(0,best)];
    all.push(...ord);
    cur=ord[ord.length-1];
  }
  return all.map(p=>{
    let t=Math.atan2(p.y-CY,p.x-CX);
    if(t<0) t+=2*Math.PI;
    const rho=Math.min(dist2(p,{x:CX,y:CY})/R,1.0);
    return [t,rho];
  });
}

function toThrString(pairs:[number,number][]):string{
  const header=`# Pattern desenat în ZeNis\n# ${new Date().toLocaleString("ro-RO")}\n`;
  return header+pairs.map(([t,r])=>`${t.toFixed(4)} ${r.toFixed(4)}`).join("\n");
}

// ── Canvas helpers ─────────────────────────────────────────────────────────────
function getPos(e:React.MouseEvent|React.TouchEvent, canvas:HTMLCanvasElement):Point{
  const r=canvas.getBoundingClientRect();
  const src="touches" in e ? e.touches[0] : e;
  return {x:(src.clientX-r.left)*(canvas.width/r.width),
          y:(src.clientY-r.top)*(canvas.height/r.height)};
}

// ── Draw grid ─────────────────────────────────────────────────────────────────
function drawGrid(ctx:CanvasRenderingContext2D){
  ctx.clearRect(0,0,SIZE,SIZE);

  // Outer ring fill
  ctx.beginPath();
  ctx.arc(CX,CY,R+4,0,Math.PI*2);
  ctx.fillStyle="#130F0A";
  ctx.fill();

  // Radial rings
  [0.25,0.5,0.75,1].forEach(f=>{
    ctx.beginPath();
    ctx.arc(CX,CY,R*f,0,Math.PI*2);
    ctx.strokeStyle=f===1?"rgba(200,169,126,0.35)":"rgba(200,169,126,0.12)";
    ctx.lineWidth=f===1?1.5:0.8;
    ctx.stroke();
  });

  // Radial spokes
  for(let i=0;i<12;i++){
    const a=(i/12)*Math.PI*2;
    ctx.beginPath();
    ctx.moveTo(CX,CY);
    ctx.lineTo(CX+R*Math.cos(a),CY+R*Math.sin(a));
    ctx.strokeStyle="rgba(200,169,126,0.08)";
    ctx.lineWidth=0.8;
    ctx.stroke();
  }

  // Center dot
  ctx.beginPath();
  ctx.arc(CX,CY,3,0,Math.PI*2);
  ctx.fillStyle=SAND_DIM;
  ctx.fill();
}

// ── Component ──────────────────────────────────────────────────────────────────
export default function DrawPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [tool, setTool] = useState<Tool>("pen");
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [currentShape, setCurrentShape] = useState<Shape|null>(null);
  const [thrOutput, setThrOutput] = useState("");
  const [status, setStatus] = useState("");
  const [sending, setSending] = useState(false);
  const isDrawing = useRef(false);
  const startPt  = useRef<Point>({x:0,y:0});
  const penPts   = useRef<Point[]>([]);

  // Redraw everything
  const redraw = useCallback((extra?:Shape)=>{
    const canvas=canvasRef.current; if(!canvas) return;
    const ctx=canvas.getContext("2d")!;
    drawGrid(ctx);
    ctx.save();
    ctx.beginPath();
    ctx.arc(CX,CY,R,0,Math.PI*2);
    ctx.clip();

    const all=[...shapes, ...(extra?[extra]:[])];
    for(const s of all){
      ctx.beginPath();
      ctx.strokeStyle=SAND;
      ctx.lineWidth=strokeWidth;
      ctx.lineCap="round";
      ctx.lineJoin="round";
      if(s.type==="pen"&&s.points){
        s.points.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y));
        ctx.stroke();
      } else if(s.type==="line"){
        ctx.moveTo(s.x0!,s.y0!); ctx.lineTo(s.x1!,s.y1!); ctx.stroke();
      } else if(s.type==="circle"){
        const rx=Math.abs(s.x1!-s.x0!)/2, ry=Math.abs(s.y1!-s.y0!)/2;
        ctx.ellipse((s.x0!+s.x1!)/2,(s.y0!+s.y1!)/2,rx,ry,0,0,Math.PI*2);
        ctx.stroke();
      } else if(s.type==="rect"){
        ctx.strokeRect(s.x0!,s.y0!,s.x1!-s.x0!,s.y1!-s.y0!);
      } else if(s.type==="triangle"){
        const tx=(s.x0!+s.x1!)/2;
        ctx.moveTo(tx,s.y0!); ctx.lineTo(s.x1!,s.y1!);
        ctx.lineTo(s.x0!,s.y1!); ctx.closePath(); ctx.stroke();
      } else if(s.type==="erase"){
        // handled via clearRect during drawing
      }
    }
    ctx.restore();
  },[shapes, strokeWidth]);

  useEffect(()=>{ redraw(); },[redraw]);

  // Mouse/touch handlers
  const onStart = useCallback((e:React.MouseEvent|React.TouchEvent)=>{
    if(!canvasRef.current) return;
    e.preventDefault();
    const p=getPos(e,canvasRef.current);
    // Check inside circle
    if(dist2(p,{x:CX,y:CY})>R+10) return;
    isDrawing.current=true;
    startPt.current=p;
    penPts.current=[p];
    if(tool==="pen"||tool==="erase"){
      setCurrentShape({type:tool,points:[p]});
    }
  },[tool]);

  const onMove = useCallback((e:React.MouseEvent|React.TouchEvent)=>{
    if(!isDrawing.current||!canvasRef.current) return;
    e.preventDefault();
    const p=getPos(e,canvasRef.current);
    const sp=startPt.current;

    if(tool==="pen"){
      penPts.current.push(p);
      const s:Shape={type:"pen",points:[...penPts.current]};
      setCurrentShape(s);
      redraw(s);
    } else if(tool==="erase"){
      const ctx=canvasRef.current.getContext("2d")!;
      ctx.save();
      ctx.beginPath();
      ctx.arc(CX,CY,R,0,Math.PI*2);
      ctx.clip();
      ctx.clearRect(p.x-20,p.y-20,40,40);
      ctx.restore();
      drawGrid(ctx);
      redraw(); // full redraw; erase handled by removing shapes
    } else {
      const s:Shape={type:tool,x0:sp.x,y0:sp.y,x1:p.x,y1:p.y};
      setCurrentShape(s);
      redraw(s);
    }
  },[tool, redraw]);

  const onEnd = useCallback(()=>{
    if(!isDrawing.current) return;
    isDrawing.current=false;
    if(currentShape && currentShape.type!=="erase"){
      setShapes(prev=>[...prev,currentShape]);
      setCurrentShape(null);
      setThrOutput(""); // reset preview
    }
  },[currentShape]);

  const clearAll=()=>{
    setShapes([]); setCurrentShape(null); setThrOutput(""); setStatus("");
    const canvas=canvasRef.current; if(!canvas) return;
    const ctx=canvas.getContext("2d")!;
    drawGrid(ctx);
  };

  const undo=()=>{
    setShapes(prev=>prev.slice(0,-1));
    setThrOutput("");
  };

  const buildThr=():string=>{
    const pairs=shapesToThetaRho(shapes);
    return toThrString(pairs);
  };

  const download=()=>{
    const thr=buildThr();
    setThrOutput(thr);
    const blob=new Blob([thr],{type:"text/plain"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download=`zenis_draw_${Date.now()}.thr`; a.click();
    URL.revokeObjectURL(url);
  };

  const sendToTable=async()=>{
    const thr=buildThr();
    if(!thr.trim()||shapes.length===0){ setStatus("⚠ Desenează ceva mai întâi"); return; }
    setSending(true);
    setStatus("Se trimite la masă...");
    try{
      // 1. Upload as temp pattern
      const filename=`zenis_draw_${Date.now()}.thr`;
      const blob=new Blob([thr],{type:"text/plain"});
      const form=new FormData();
      form.append("file",blob,filename);
      const up=await fetch("/api/patterns/upload",{method:"POST",body:form});
      if(!up.ok) throw new Error("Upload eșuat");

      // 2. Run it immediately
      const run=await fetch("/api/run-pattern",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({file_name:filename}),
      });
      if(!run.ok) throw new Error("Start eșuat");
      setStatus("✓ Pattern trimis! Masa desenează...");
    }catch(err:unknown){
      setStatus(`✗ Eroare: ${err instanceof Error ? err.message : "necunoscută"}`);
    }finally{
      setSending(false);
    }
  };

  const TOOLS:[Tool,typeof Pencil,string][]=[
    ["pen",    Pencil,   "Liber"],
    ["line",   Minus,    "Linie"],
    ["circle", Circle,   "Cerc"],
    ["rect",   Square,   "Dreptunghi"],
    ["triangle",Triangle,"Triunghi"],
    ["erase",  Eraser,   "Radieră"],
  ];

  return (
    <div className="flex flex-col gap-6 p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold" style={{color:"#C8A97E"}}>
            Desenează
          </h1>
          <p className="text-sm mt-0.5" style={{color:"rgba(240,230,211,0.45)"}}>
            Trasează un pattern pe nisip — click sau touch pe canvas
          </p>
        </div>
        <Badge variant="outline" style={{borderColor:"rgba(200,169,126,0.3)",color:"#C8A97E"}}>
          {shapes.length} forme
        </Badge>
      </div>

      <div className="flex gap-6 flex-wrap lg:flex-nowrap">
        {/* Canvas */}
        <div className="flex flex-col items-center gap-4">
          <canvas
            ref={canvasRef}
            width={SIZE}
            height={SIZE}
            className="touch-none select-none rounded-full"
            style={{
              background:BG,
              cursor: tool==="erase"?"crosshair":"default",
              boxShadow:"0 0 40px rgba(200,169,126,0.10)",
              maxWidth:"100%",
            }}
            onMouseDown={onStart}
            onMouseMove={onMove}
            onMouseUp={onEnd}
            onMouseLeave={onEnd}
            onTouchStart={onStart}
            onTouchMove={onMove}
            onTouchEnd={onEnd}
          />

          {/* Status */}
          {status && (
            <p className="text-sm" style={{color:status.startsWith("✓")?"#86efac":status.startsWith("✗")?"#fca5a5":"#C8A97E"}}>
              {status}
            </p>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-col gap-5 min-w-[220px] flex-1">

          {/* Tool picker */}
          <div className="rounded-xl p-4 flex flex-col gap-3"
               style={{background:"#1A1610",border:"1px solid rgba(200,169,126,0.12)"}}>
            <span className="text-xs tracking-widest" style={{color:"rgba(240,230,211,0.35)"}}>
              INSTRUMENT
            </span>
            <div className="grid grid-cols-3 gap-2">
              {TOOLS.map(([t,Icon,label])=>(
                <button
                  key={t}
                  onClick={()=>setTool(t)}
                  className="flex flex-col items-center gap-1 rounded-lg py-2 px-1 text-xs transition-all"
                  style={{
                    background: tool===t?"rgba(200,169,126,0.18)":"transparent",
                    border: `1px solid ${tool===t?"rgba(200,169,126,0.5)":"rgba(200,169,126,0.1)"}`,
                    color: tool===t?"#C8A97E":"rgba(240,230,211,0.5)",
                  }}
                >
                  <Icon size={16}/>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Stroke width */}
          <div className="rounded-xl p-4 flex flex-col gap-3"
               style={{background:"#1A1610",border:"1px solid rgba(200,169,126,0.12)"}}>
            <div className="flex justify-between items-center">
              <span className="text-xs tracking-widest" style={{color:"rgba(240,230,211,0.35)"}}>
                GROSIME LINIE
              </span>
              <span className="text-sm" style={{color:"#C8A97E"}}>{strokeWidth}px</span>
            </div>
            <Slider
              min={1} max={12} step={1}
              value={[strokeWidth]}
              onValueChange={([v])=>setStrokeWidth(v)}
              className="accent-sand"
            />
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2">
            <Button
              onClick={sendToTable}
              disabled={sending||shapes.length===0}
              className="w-full gap-2"
              style={{background:"#C8A97E",color:"#0E0C09"}}
            >
              <Play size={16}/> Trimite la masă
            </Button>
            <Button
              onClick={download}
              disabled={shapes.length===0}
              variant="outline"
              className="w-full gap-2"
              style={{borderColor:"rgba(200,169,126,0.3)",color:"#C8A97E"}}
            >
              <Download size={16}/> Descarcă .thr
            </Button>
            <div className="flex gap-2">
              <Button
                onClick={undo}
                disabled={shapes.length===0}
                variant="outline"
                className="flex-1 gap-1"
                style={{borderColor:"rgba(200,169,126,0.2)",color:"rgba(240,230,211,0.6)"}}
              >
                <RotateCcw size={14}/> Undo
              </Button>
              <Button
                onClick={clearAll}
                disabled={shapes.length===0}
                variant="outline"
                className="flex-1 gap-1"
                style={{borderColor:"rgba(200,169,126,0.2)",color:"rgba(240,230,211,0.6)"}}
              >
                <Trash2 size={14}/> Șterge tot
              </Button>
            </div>
          </div>

          {/* .thr preview */}
          {thrOutput && (
            <div className="rounded-xl p-3"
                 style={{background:"#130F0A",border:"1px solid rgba(200,169,126,0.1)"}}>
              <p className="text-xs mb-2 tracking-widest" style={{color:"rgba(240,230,211,0.35)"}}>
                PREVIZUALIZARE .THR
              </p>
              <pre className="text-xs overflow-auto max-h-40"
                   style={{color:"rgba(200,169,126,0.7)",fontFamily:"'DM Mono',monospace"}}>
                {thrOutput.split("\n").slice(0,20).join("\n")}
                {thrOutput.split("\n").length>20 ? "\n…" : ""}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
