/**
 * AudioPage.tsx  —  ZeNis Audio
 * Pune în: frontend/src/pages/AudioPage.tsx
 *
 * Tab separat. Funcții:
 *  - Scan & pair Bluetooth speakers
 *  - Upload fișiere audio (mp3/wav/ogg/flac)
 *  - Play / Stop / Volum
 */

import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Bluetooth,
  BluetoothConnected,
  BluetoothSearching,
  Music,
  Play,
  Square,
  Upload,
  Volume2,
  Trash2,
  RefreshCw,
  Loader2,
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────
interface BtDevice  { mac: string; name: string }
interface AudioStatus {
  playing: boolean;
  current_file: string | null;
  bt_device: string | null;
  volume: number;
  files: string[];
}

// ── API helpers ───────────────────────────────────────────────────────────────
const api = {
  status:     ():Promise<AudioStatus> => fetch("/api/audio/status").then(r=>r.json()),
  scan:       ():Promise<{devices:BtDevice[]}> => fetch("/api/audio/bluetooth/scan").then(r=>r.json()),
  pair:       (mac:string) => fetch("/api/audio/bluetooth/pair",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mac})}).then(r=>r.json()),
  disconnect: () => fetch("/api/audio/bluetooth/disconnect",{method:"POST"}).then(r=>r.json()),
  play:       (filename:string) => fetch("/api/audio/play",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({filename})}).then(r=>r.json()),
  stop:       () => fetch("/api/audio/stop",{method:"POST"}).then(r=>r.json()),
  volume:     (v:number) => fetch("/api/audio/volume",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({volume:v})}).then(r=>r.json()),
  deleteFile: (f:string) => fetch(`/api/audio/files/${encodeURIComponent(f)}`,{method:"DELETE"}).then(r=>r.json()),
};

// ── Component ──────────────────────────────────────────────────────────────────
export default function AudioPage() {
  const [status, setStatus]       = useState<AudioStatus|null>(null);
  const [btDevices, setBtDevices] = useState<BtDevice[]>([]);
  const [scanning, setScanning]   = useState(false);
  const [pairing, setPairing]     = useState<string|null>(null);
  const [volume, setVolume]       = useState(80);
  const [msg, setMsg]             = useState("");
  const fileInputRef              = useRef<HTMLInputElement>(null);
  const pollRef                   = useRef<ReturnType<typeof setInterval>>(undefined);

  const refresh = async()=>{
    try{
      const s = await api.status();
      setStatus(s);
      setVolume(s.volume);
    } catch { /* backend poate nu are modulul audio încă */ }
  };

  useEffect(()=>{
    refresh();
    pollRef.current = setInterval(refresh, 3000);
    return ()=>clearInterval(pollRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);

  const scan=async()=>{
    setScanning(true); setMsg("Scanez dispozitive Bluetooth (~8s)...");
    const res=await api.scan();
    setBtDevices(res.devices||[]);
    setScanning(false);
    setMsg(res.devices?.length ? `${res.devices.length} dispozitive găsite` : "Niciun dispozitiv găsit. Asigură-te că boxa e în modul pairing.");
  };

  const pair=async(mac:string)=>{
    setPairing(mac); setMsg("Se conectează...");
    const res=await api.pair(mac);
    setMsg(res.success ? `✓ ${res.message}` : `✗ ${res.message}`);
    setPairing(null);
    refresh();
  };

  const disconnect=async()=>{
    await api.disconnect();
    setMsg("Deconectat");
    refresh();
  };

  const play=async(f:string)=>{
    const res=await api.play(f);
    setMsg(res.success ? `▶ ${f}` : `✗ ${res.message}`);
    refresh();
  };

  const stop=async()=>{
    await api.stop();
    setMsg("Oprit");
    refresh();
  };

  const changeVolume=async(v:number)=>{
    setVolume(v);
    await api.volume(v);
  };

  const uploadFile=async(e:React.ChangeEvent<HTMLInputElement>)=>{
    const file=e.target.files?.[0]; if(!file) return;
    setMsg("Se încarcă...");
    const form=new FormData();
    form.append("file",file);
    const res=await fetch("/api/audio/upload",{method:"POST",body:form}).then(r=>r.json());
    setMsg(res.success ? `✓ ${file.name} încărcat` : `✗ ${res.detail||"eroare"}`);
    refresh();
    if(fileInputRef.current) fileInputRef.current.value="";
  };

  const deleteFile=async(f:string)=>{
    if(!confirm(`Ștergi "${f}"?`)) return;
    await api.deleteFile(f);
    setMsg(`Șters: ${f}`);
    refresh();
  };

  const SAND="#C8A97E";
  const CARD={background:"#1A1610",border:"1px solid rgba(200,169,126,0.12)",borderRadius:"12px",padding:"16px"};
  const textDim="rgba(240,230,211,0.45)";
  const label={fontSize:"11px",letterSpacing:"0.1em",color:"rgba(240,230,211,0.35)"};

  return (
    <div className="flex flex-col gap-6 p-6 max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold" style={{color:SAND}}>Audio</h1>
          <p className="text-sm mt-0.5" style={{color:textDim}}>
            Boxa Bluetooth + player fișiere
          </p>
        </div>
        {status?.playing && (
          <Badge style={{background:"rgba(200,169,126,0.15)",color:SAND,border:"1px solid rgba(200,169,126,0.3)"}}>
            ▶ {status.current_file}
          </Badge>
        )}
      </div>

      {/* Mesaj status */}
      {msg && (
        <p className="text-sm px-4 py-2 rounded-lg"
           style={{background:"rgba(200,169,126,0.08)",color:SAND,border:"1px solid rgba(200,169,126,0.15)"}}>
          {msg}
        </p>
      )}

      {/* ── Bluetooth ─────────────────────────────────────────────────────── */}
      <div style={CARD}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            {status?.bt_device
              ? <BluetoothConnected size={18} style={{color:SAND}}/>
              : <Bluetooth size={18} style={{color:textDim}}/>
            }
            <span style={label}>BLUETOOTH</span>
          </div>
          {status?.bt_device
            ? <Button size="sm" variant="outline" onClick={disconnect}
                      style={{borderColor:"rgba(200,169,126,0.2)",color:textDim}}>
                Deconectează
              </Button>
            : <Button size="sm" onClick={scan} disabled={scanning}
                      style={{background:SAND,color:"#0E0C09"}} className="gap-2">
                {scanning ? <Loader2 size={14} className="animate-spin"/> : <BluetoothSearching size={14}/>}
                {scanning ? "Scanez..." : "Scanează"}
              </Button>
          }
        </div>

        {status?.bt_device && (
          <div className="flex items-center gap-2 p-3 rounded-lg"
               style={{background:"rgba(200,169,126,0.08)",border:"1px solid rgba(200,169,126,0.2)"}}>
            <BluetoothConnected size={14} style={{color:SAND}}/>
            <span className="text-sm" style={{color:SAND}}>Conectat: {status.bt_device}</span>
          </div>
        )}

        {btDevices.length>0 && !status?.bt_device && (
          <div className="flex flex-col gap-2">
            {btDevices.map(d=>(
              <div key={d.mac} className="flex items-center justify-between p-3 rounded-lg"
                   style={{background:"rgba(200,169,126,0.05)",border:"1px solid rgba(200,169,126,0.1)"}}>
                <div>
                  <p className="text-sm" style={{color:"#F0E6D3"}}>{d.name||"Dispozitiv necunoscut"}</p>
                  <p className="text-xs" style={{color:textDim}}>{d.mac}</p>
                </div>
                <Button size="sm" onClick={()=>pair(d.mac)} disabled={pairing===d.mac}
                        style={{background:SAND,color:"#0E0C09"}} className="gap-1">
                  {pairing===d.mac ? <Loader2 size={12} className="animate-spin"/> : null}
                  Conectează
                </Button>
              </div>
            ))}
          </div>
        )}

        {!status?.bt_device && btDevices.length===0 && !scanning && (
          <p className="text-sm text-center py-4" style={{color:textDim}}>
            Apasă "Scanează" și pune boxa în modul pairing
          </p>
        )}
      </div>

      {/* ── Volum ─────────────────────────────────────────────────────────── */}
      <div style={CARD}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Volume2 size={18} style={{color:textDim}}/>
            <span style={label}>VOLUM</span>
          </div>
          <span className="text-sm font-medium" style={{color:SAND}}>{volume}%</span>
        </div>
        <Slider min={0} max={100} step={1} value={[volume]}
                onValueChange={([v])=>changeVolume(v)}/>
      </div>

      {/* ── Player ────────────────────────────────────────────────────────── */}
      <div style={CARD}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Music size={18} style={{color:textDim}}/>
            <span style={label}>FIȘIERE AUDIO</span>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={refresh}
                    style={{borderColor:"rgba(200,169,126,0.2)",color:textDim}}>
              <RefreshCw size={13}/>
            </Button>
            <Button size="sm" onClick={()=>fileInputRef.current?.click()}
                    style={{background:SAND,color:"#0E0C09"}} className="gap-1">
              <Upload size={13}/> Upload
            </Button>
            <input ref={fileInputRef} type="file"
                   accept=".mp3,.wav,.ogg,.flac,.aac"
                   className="hidden" onChange={uploadFile}/>
          </div>
        </div>

        {/* Now playing */}
        {status?.playing && (
          <div className="flex items-center justify-between p-3 mb-3 rounded-lg"
               style={{background:"rgba(200,169,126,0.10)",border:"1px solid rgba(200,169,126,0.25)"}}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full animate-pulse" style={{background:SAND}}/>
              <span className="text-sm" style={{color:SAND}}>{status.current_file}</span>
            </div>
            <Button size="sm" onClick={stop}
                    style={{borderColor:"rgba(200,169,126,0.3)",color:"#F0E6D3"}} variant="outline"
                    className="gap-1">
              <Square size={12}/> Stop
            </Button>
          </div>
        )}

        {/* File list */}
        {status?.files && status.files.length>0 ? (
          <div className="flex flex-col gap-1">
            {status.files.map(f=>(
              <div key={f} className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/5 transition-colors">
                <div className="flex items-center gap-2">
                  <Music size={14} style={{color:textDim}}/>
                  <span className="text-sm" style={{color:status.current_file===f?SAND:"#F0E6D3"}}>
                    {f}
                  </span>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={()=>play(f)}
                          style={{color:SAND}} className="h-7 w-7 p-0">
                    <Play size={13}/>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={()=>deleteFile(f)}
                          style={{color:"rgba(240,230,211,0.3)"}} className="h-7 w-7 p-0">
                    <Trash2 size={13}/>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 flex flex-col items-center gap-2">
            <Music size={32} style={{color:"rgba(200,169,126,0.2)"}}/>
            <p className="text-sm" style={{color:textDim}}>
              Niciun fișier audio. Apasă Upload pentru a adăuga.
            </p>
            <p className="text-xs" style={{color:"rgba(240,230,211,0.25)"}}>
              Suportat: MP3, WAV, OGG, FLAC, AAC
            </p>
          </div>
        )}
      </div>

      {/* Install note */}
      <div className="rounded-lg px-4 py-3"
           style={{background:"rgba(200,169,126,0.04)",border:"1px solid rgba(200,169,126,0.08)"}}>
        <p className="text-xs" style={{color:"rgba(240,230,211,0.3)"}}>
          💡 Prima dată rulează pe Pi:{" "}
          <code style={{color:"rgba(200,169,126,0.6)"}}>sudo apt install mpg123 ffmpeg bluez pulseaudio-module-bluetooth</code>
        </p>
      </div>
    </div>
  );
}
