import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Circle, Square, Triangle, Minus, Eraser, Trash2, Play, RotateCcw, Eye, Bookmark } from "lucide-react";

const SIZE=480,CX=SIZE/2,CY=SIZE/2,R=SIZE/2-16,SW=2;
const SAND="#C8A97E",SAND_DIM="rgba(200,169,126,0.25)",BG="#0E0C09",PSIZE=380;
type Tool="pen"|"line"|"circle"|"rect"|"triangle"|"erase";
interface Pt{x:number;y:number}
interface Shape{type:Tool;points?:Pt[];x0?:number;y0?:number;x1?:number;y1?:number}

function sampleLine(x0:number,y0:number,x1:number,y1:number,n=60):Pt[]{return Array.from({length:n},(_,i)=>({x:x0+(x1-x0)*(i/n),y:y0+(y1-y0)*(i/n)}));}
function sampleArc(cx:number,cy:number,rx:number,ry:number,n=120):Pt[]{return Array.from({length:n},(_,i)=>{const a=(i/(n-1))*Math.PI*2;return{x:cx+rx*Math.cos(a),y:cy+ry*Math.sin(a)};});}
function dist(a:Pt,b:Pt){return Math.sqrt((a.x-b.x)**2+(a.y-b.y)**2);}
function shapeToPoints(s:Shape):Pt[]{
  switch(s.type){
    case"pen":return(s.points||[]).filter((_,i)=>i%2===0);
    case"line":return sampleLine(s.x0!,s.y0!,s.x1!,s.y1!);
    case"circle":{const rx=Math.abs(s.x1!-s.x0!)/2,ry=Math.abs(s.y1!-s.y0!)/2;return sampleArc((s.x0!+s.x1!)/2,(s.y0!+s.y1!)/2,rx,ry);}
    case"rect":{const x0=Math.min(s.x0!,s.x1!),y0=Math.min(s.y0!,s.y1!),x1=Math.max(s.x0!,s.x1!),y1=Math.max(s.y0!,s.y1!);return[...sampleLine(x0,y0,x1,y0),...sampleLine(x1,y0,x1,y1),...sampleLine(x1,y1,x0,y1),...sampleLine(x0,y1,x0,y0)];}
    case"triangle":{const tx=(s.x0!+s.x1!)/2;return[...sampleLine(tx,s.y0!,s.x1!,s.y1!),...sampleLine(s.x1!,s.y1!,s.x0!,s.y1!),...sampleLine(s.x0!,s.y1!,tx,s.y0!)];}
    default:return[];
  }
}
function shapesToThetaRho(shapes:Shape[]):[number,number][]{
  const all:Pt[]=[];
  for(const s of shapes){const pts=shapeToPoints(s);if(pts.length)all.push(...pts);}
  return all.map(p=>{let t=Math.atan2(p.y-CY,p.x-CX);if(t<0)t+=2*Math.PI;return[t,Math.min(dist(p,{x:CX,y:CY})/R,1.0)] as [number,number];});
}
function buildThr(pairs:[number,number][]):string{
  return"# ZeNis Draw\n# "+new Date().toLocaleString("ro-RO")+"\n"+pairs.map(([t,r])=>`${t.toFixed(4)} ${r.toFixed(4)}`).join("\n");
}
function drawGrid(ctx:CanvasRenderingContext2D,size:number,r:number){
  const cx=size/2,cy=size/2;
  ctx.clearRect(0,0,size,size);
  ctx.beginPath();ctx.arc(cx,cy,r+4,0,Math.PI*2);ctx.fillStyle="#130F0A";ctx.fill();
  [0.25,0.5,0.75,1].forEach(f=>{ctx.beginPath();ctx.arc(cx,cy,r*f,0,Math.PI*2);ctx.strokeStyle=f===1?"rgba(200,169,126,0.35)":"rgba(200,169,126,0.12)";ctx.lineWidth=f===1?1.5:0.8;ctx.stroke();});
  for(let i=0;i<12;i++){const a=(i/12)*Math.PI*2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(cx+r*Math.cos(a),cy+r*Math.sin(a));ctx.strokeStyle="rgba(200,169,126,0.08)";ctx.lineWidth=0.8;ctx.stroke();}
  ctx.beginPath();ctx.arc(cx,cy,3,0,Math.PI*2);ctx.fillStyle=SAND_DIM;ctx.fill();
}
function getPos(e:React.MouseEvent|React.TouchEvent,canvas:HTMLCanvasElement):Pt{
  const rect=canvas.getBoundingClientRect(),src="touches"in e?e.touches[0]:e;
  return{x:(src.clientX-rect.left)*(canvas.width/rect.width),y:(src.clientY-rect.top)*(canvas.height/rect.height)};
}

async function uploadAndRun(thr:string,fname:string,run:boolean):Promise<void>{
  const form=new FormData();
  form.append("file",new Blob([thr],{type:"text/plain"}),fname);
  const up=await fetch("/upload_theta_rho",{method:"POST",body:form});
  if(!up.ok){const e=await up.json();throw new Error(e.detail||"Upload eșuat");}
  if(run){
    const r=await fetch("/run_theta_rho",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({file_name:fname})});
    if(!r.ok){const e=await r.json();throw new Error(e.detail||"Start eșuat");}
  }
}

function PreviewModal({pairs,onClose,onSend}:{pairs:[number,number][];onClose:()=>void;onSend:()=>void}){
  const cvRef=useRef<HTMLCanvasElement>(null);
  const animRef=useRef<number>(0);
  const progRef=useRef(0);
  const pausedRef=useRef(false);
  const [progress,setProgress]=useState(0);
  const [paused,setPaused]=useState(false);

  const draw=useCallback((prog:number)=>{
    const cv=cvRef.current;if(!cv)return;
    const ctx=cv.getContext("2d")!;
    const cx=PSIZE/2,cy=PSIZE/2,r=PSIZE/2-20;
    drawGrid(ctx,PSIZE,r);
    ctx.save();ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.clip();
    if(pairs.length>1){
      const total=pairs.length,upTo=Math.floor(prog*total);
      ctx.beginPath();
      for(let i=0;i<=upTo;i++){const[t,rho]=pairs[i];const x=cx+r*rho*Math.cos(t),y=cy+r*rho*Math.sin(t);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);}
      ctx.strokeStyle=SAND;ctx.lineWidth=1.5;ctx.globalAlpha=0.6;ctx.stroke();ctx.globalAlpha=1;
      if(upTo>0){
        const[t,rho]=pairs[Math.min(upTo,total-1)];
        const bx=cx+r*rho*Math.cos(t),by=cy+r*rho*Math.sin(t);
        const g=ctx.createRadialGradient(bx,by,0,bx,by,14);
        g.addColorStop(0,"rgba(200,169,126,0.6)");g.addColorStop(1,"transparent");
        ctx.beginPath();ctx.arc(bx,by,14,0,Math.PI*2);ctx.fillStyle=g;ctx.fill();
        ctx.beginPath();ctx.arc(bx,by,5,0,Math.PI*2);ctx.fillStyle=SAND;ctx.fill();
        ctx.strokeStyle="#fff";ctx.lineWidth=1;ctx.stroke();
      }
    }
    ctx.restore();
  },[pairs]);

  useEffect(()=>{
    const loop=()=>{
      if(!pausedRef.current&&pairs.length>0){
        progRef.current=Math.min(progRef.current+0.005,1);
        setProgress(progRef.current);draw(progRef.current);
        if(progRef.current>=1)setTimeout(()=>{progRef.current=0;},800);
      }
      animRef.current=requestAnimationFrame(loop);
    };
    animRef.current=requestAnimationFrame(loop);
    return()=>cancelAnimationFrame(animRef.current);
  },[draw,pairs.length]);

  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.92)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
      <div style={{background:"#1A1610",border:"1px solid rgba(200,169,126,0.2)",borderRadius:20,padding:24,display:"flex",flexDirection:"column",alignItems:"center",gap:14,maxWidth:460,width:"100%"}}>
        <div style={{width:"100%",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div><div style={{fontSize:15,fontWeight:500,color:"#F0E6D3"}}>Previzualizare masă nisip</div>
          <div style={{fontSize:11,color:"rgba(240,230,211,0.4)",fontFamily:"monospace"}}>{pairs.length} puncte θ-ρ</div></div>
          <button onClick={onClose} style={{background:"transparent",border:"1px solid rgba(200,169,126,0.2)",color:"rgba(240,230,211,0.5)",borderRadius:8,padding:"5px 10px",cursor:"pointer",fontSize:12}}>✕ Închide</button>
        </div>
        <canvas ref={cvRef} width={PSIZE} height={PSIZE} style={{width:320,height:320,borderRadius:"50%",border:"1px solid rgba(200,169,126,0.2)"}}/>
        <div style={{width:"100%",height:3,background:"rgba(200,169,126,0.1)",borderRadius:2,overflow:"hidden"}}>
          <div style={{height:"100%",width:`${progress*100}%`,background:"linear-gradient(90deg,#9B7D5A,#C8A97E)",transition:"width .1s"}}/>
        </div>
        <div style={{display:"flex",gap:10,width:"100%"}}>
          <button onClick={()=>{pausedRef.current=!pausedRef.current;setPaused(p=>!p);}}
            style={{flex:1,padding:11,borderRadius:10,background:"rgba(200,169,126,0.1)",border:"1px solid rgba(200,169,126,0.2)",color:SAND,cursor:"pointer",fontWeight:600,fontSize:13}}>
            {paused?"▶ Continuă":"⏸ Pauză"}
          </button>
          <button onClick={()=>{progRef.current=0;setProgress(0);pausedRef.current=false;setPaused(false);}}
            style={{flex:1,padding:11,borderRadius:10,background:"rgba(200,169,126,0.1)",border:"1px solid rgba(200,169,126,0.2)",color:SAND,cursor:"pointer",fontWeight:600,fontSize:13}}>
            ↺ Restart
          </button>
        </div>
        <button onClick={onSend}
          style={{width:"100%",padding:14,borderRadius:10,background:SAND,color:"#0E0C09",cursor:"pointer",fontWeight:700,fontSize:14,border:"none"}}>
          ▶ Trimite la masă
        </button>
      </div>
    </div>
  );
}

export default function DrawPage(){
  const canvasRef=useRef<HTMLCanvasElement>(null);
  const [tool,setTool]=useState<Tool>("pen");
  const [shapes,setShapes]=useState<Shape[]>([]);
  const [cur,setCur]=useState<Shape|null>(null);
  const [status,setStatus]=useState("");
  const [statusColor,setStatusColor]=useState(SAND);
  const [sending,setSending]=useState(false);
  const [saving,setSaving]=useState(false);
  const [showPreview,setShowPreview]=useState(false);
  const drawing=useRef(false);
  const startPt=useRef<Pt>({x:0,y:0});
  const penPts=useRef<Pt[]>([]);

  const pairs=shapesToThetaRho(shapes);

  const redraw=useCallback((extra?:Shape)=>{
    const c=canvasRef.current;if(!c)return;
    const ctx=c.getContext("2d")!;
    drawGrid(ctx,SIZE,R);
    ctx.save();ctx.beginPath();ctx.arc(CX,CY,R,0,Math.PI*2);ctx.clip();
    for(const s of[...shapes,...(extra?[extra]:[])]){
      ctx.beginPath();ctx.strokeStyle=SAND;ctx.lineWidth=SW;ctx.lineCap="round";ctx.lineJoin="round";
      if(s.type==="pen"&&s.points){s.points.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y));ctx.stroke();}
      else if(s.type==="line"){ctx.moveTo(s.x0!,s.y0!);ctx.lineTo(s.x1!,s.y1!);ctx.stroke();}
      else if(s.type==="circle"){const rx=Math.abs(s.x1!-s.x0!)/2,ry=Math.abs(s.y1!-s.y0!)/2;ctx.ellipse((s.x0!+s.x1!)/2,(s.y0!+s.y1!)/2,rx,ry,0,0,Math.PI*2);ctx.stroke();}
      else if(s.type==="rect"){ctx.strokeRect(s.x0!,s.y0!,s.x1!-s.x0!,s.y1!-s.y0!);}
      else if(s.type==="triangle"){const tx=(s.x0!+s.x1!)/2;ctx.moveTo(tx,s.y0!);ctx.lineTo(s.x1!,s.y1!);ctx.lineTo(s.x0!,s.y1!);ctx.closePath();ctx.stroke();}
    }
    ctx.restore();
  },[shapes]);

  useEffect(()=>{redraw();},[redraw]);

  const onStart=useCallback((e:React.MouseEvent|React.TouchEvent)=>{
    if(!canvasRef.current)return;e.preventDefault();
    const p=getPos(e,canvasRef.current);
    if(dist(p,{x:CX,y:CY})>R+10)return;
    drawing.current=true;startPt.current=p;penPts.current=[p];
    if(tool==="pen")setCur({type:"pen",points:[p]});
  },[tool]);

  const onMove=useCallback((e:React.MouseEvent|React.TouchEvent)=>{
    if(!drawing.current||!canvasRef.current)return;e.preventDefault();
    const p=getPos(e,canvasRef.current),sp=startPt.current;
    if(tool==="pen"){penPts.current.push(p);const s={type:"pen" as Tool,points:[...penPts.current]};setCur(s);redraw(s);}
    else if(tool==="erase"){const ctx=canvasRef.current.getContext("2d")!;ctx.save();ctx.beginPath();ctx.arc(CX,CY,R,0,Math.PI*2);ctx.clip();ctx.clearRect(p.x-20,p.y-20,40,40);ctx.restore();redraw();}
    else{const s={type:tool,x0:sp.x,y0:sp.y,x1:p.x,y1:p.y};setCur(s);redraw(s);}
  },[tool,redraw]);

  const onEnd=useCallback(()=>{
    if(!drawing.current)return;drawing.current=false;
    if(cur&&cur.type!=="erase"){setShapes(p=>[...p,cur]);setCur(null);}
  },[cur]);

  const clear=()=>{setShapes([]);setCur(null);setStatus("");const c=canvasRef.current;if(c)drawGrid(c.getContext("2d")!,SIZE,R);};
  const undo=()=>setShapes(p=>p.slice(0,-1));
  const setMsg=(msg:string,ok?:boolean)=>{setStatus(msg);setStatusColor(ok===true?"#86efac":ok===false?"#fca5a5":SAND);};

  const saveToLibrary=async()=>{
    if(!shapes.length){setMsg("⚠ Desenează ceva mai întâi");return;}
    setSaving(true);setMsg("Se salvează...");
    try{
      const fname=`zenis_draw_${Date.now()}.thr`;
      await uploadAndRun(buildThr(pairs),fname,false);
      setMsg("✓ Salvat în librărie! Îl găsești în Browse.",true);
    }catch(e:unknown){setMsg(`✗ ${e instanceof Error?e.message:"Eroare"}`,false);}
    setSaving(false);
  };

  const sendToTable=async()=>{
    if(!shapes.length){setMsg("⚠ Desenează ceva mai întâi");return;}
    setSending(true);setMsg("Se trimite...");setShowPreview(false);
    try{
      const fname=`zenis_draw_${Date.now()}.thr`;
      await uploadAndRun(buildThr(pairs),fname,true);
      setMsg("✓ Trimis! Masa desenează...",true);
    }catch(e:unknown){setMsg(`✗ ${e instanceof Error?e.message:"Eroare"}`,false);}
    setSending(false);
  };

  const TOOLS:[Tool,typeof Pencil,string][]=[["pen",Pencil,"Liber"],["line",Minus,"Linie"],["circle",Circle,"Cerc"],["rect",Square,"Dreptunghi"],["triangle",Triangle,"Triunghi"],["erase",Eraser,"Radieră"]];

  return(
    <>
    {showPreview&&<PreviewModal pairs={pairs} onClose={()=>setShowPreview(false)} onSend={sendToTable}/>}
    <div className="flex flex-col gap-6 p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-semibold" style={{color:SAND}}>Desenează</h1>
        <p className="text-sm mt-0.5" style={{color:"rgba(240,230,211,0.45)"}}>Trasează un pattern pe nisip</p></div>
        <Badge variant="outline" style={{borderColor:"rgba(200,169,126,0.3)",color:SAND}}>{shapes.length} forme</Badge>
      </div>
      <div className="flex gap-6 flex-wrap lg:flex-nowrap">
        <div className="flex flex-col items-center gap-4">
          <canvas ref={canvasRef} width={SIZE} height={SIZE} className="touch-none select-none rounded-full"
            style={{background:BG,cursor:"crosshair",boxShadow:"0 0 40px rgba(200,169,126,0.10)",maxWidth:"100%"}}
            onMouseDown={onStart} onMouseMove={onMove} onMouseUp={onEnd} onMouseLeave={onEnd}
            onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}/>
          {status&&<p className="text-sm" style={{color:statusColor}}>{status}</p>}
        </div>
        <div className="flex flex-col gap-4 min-w-[200px] flex-1">
          <div className="rounded-xl p-4 flex flex-col gap-3" style={{background:"#1A1610",border:"1px solid rgba(200,169,126,0.12)"}}>
            <span className="text-xs tracking-widest" style={{color:"rgba(240,230,211,0.35)"}}>INSTRUMENT</span>
            <div className="grid grid-cols-3 gap-2">
              {TOOLS.map(([t,Icon,label])=>(
                <button key={t} onClick={()=>setTool(t)} className="flex flex-col items-center gap-1 rounded-lg py-2 px-1 text-xs transition-all"
                  style={{background:tool===t?"rgba(200,169,126,0.18)":"transparent",border:`1px solid ${tool===t?"rgba(200,169,126,0.5)":"rgba(200,169,126,0.1)"}`,color:tool===t?SAND:"rgba(240,230,211,0.5)"}}>
                  <Icon size={16}/>{label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <Button onClick={()=>setShowPreview(true)} disabled={!shapes.length} className="w-full gap-2"
              style={{background:"rgba(200,169,126,0.12)",color:SAND,border:"1px solid rgba(200,169,126,0.3)"}}>
              <Eye size={16}/>Previzualizează
            </Button>
            <Button onClick={sendToTable} disabled={sending||!shapes.length} className="w-full gap-2" style={{background:SAND,color:"#0E0C09"}}>
              <Play size={16}/>{sending?"Se trimite...":"Trimite la masă"}
            </Button>
            <Button onClick={saveToLibrary} disabled={saving||!shapes.length} variant="outline" className="w-full gap-2"
              style={{borderColor:"rgba(200,169,126,0.3)",color:SAND}}>
              <Bookmark size={16}/>{saving?"Se salvează...":"Salvează în librărie"}
            </Button>
            <div className="flex gap-2">
              <Button onClick={undo} disabled={!shapes.length} variant="outline" className="flex-1 gap-1"
                style={{borderColor:"rgba(200,169,126,0.2)",color:"rgba(240,230,211,0.6)"}}>
                <RotateCcw size={14}/>Undo
              </Button>
              <Button onClick={clear} disabled={!shapes.length} variant="outline" className="flex-1 gap-1"
                style={{borderColor:"rgba(200,169,126,0.2)",color:"rgba(240,230,211,0.6)"}}>
                <Trash2 size={14}/>Șterge
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
