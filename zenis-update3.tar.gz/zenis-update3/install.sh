#!/bin/bash
DW="$HOME/dune-weaver"
PATCH="$(cd "$(dirname "$0")" && pwd)"
cp "$PATCH/frontend/src/pages/DrawPage.tsx" "$DW/frontend/src/pages/"
rm -f "$DW/static/dist/assets/index-"*.js "$DW/static/dist/assets/index-"*.css
cp "$PATCH/static/dist/assets/"* "$DW/static/dist/assets/"
cp "$PATCH/static/dist/index.html" "$DW/static/dist/"
cp "$PATCH/static/dist/sw.js" "$DW/static/dist/"
cp "$PATCH/static/dist/registerSW.js" "$DW/static/dist/"
sudo systemctl restart dune-weaver
echo "✓ ZeNis Draw actualizat!"
